"""N=20 sequential study with a 4x larger decision ensemble (RA=2000) and 5000 evaluation realisations (reviewer point A3). Same instances as seq_big.py (same seeds). The 160,000-plan enumeration is replaced by: surrogate fitted on M=6000 plans; exact argmin of the surrogate over all plans; 'shortlist oracle' = best of the 300 best-by-surrogate plans re-evaluated on the decision ensemble."""
import sys, json, time, numpy as np
sys.path.insert(0, '.')
import seq, anneal as A

def run(n, sd, RA=2000, RB=5000, M_fit=6000, TA=40.0, T=4, k=1):
    rng = np.random.default_rng(1000 + sd)
    F = seq.Fire(n, rng, R=1)
    g = np.random.default_rng(777 + sd)
    F.UA = g.random((RA, F.Tmax, n, n)); UB = g.random((RB, F.Tmax, n, n))
    P = seq.ProductDicke(n, k, T, F.edges)
    t0 = time.time()
    fit = rng.choice(P.dim, M_fit, replace=False)
    y = np.array([F.loss(P.X[a].reshape(T, n), F.UA)[0] for a in fit])
    coef, *_ = np.linalg.lstsq(seq.features(P.X[fit].astype(float)), y, rcond=None)
    Esur = np.concatenate([seq.features(P.X[i:i + 4000].astype(float)) @ coef for i in range(0, P.dim, 4000)])
    hold = rng.choice(np.setdiff1d(np.arange(P.dim), fit), 500, replace=False)
    yh = np.array([F.loss(P.X[a].reshape(T, n), F.UA)[0] for a in hold])
    r2_out = 1 - np.var(yh - Esur[hold]) / np.var(yh)
    short = np.argsort(Esur)[:300]
    ys = np.array([F.loss(P.X[a].reshape(T, n), F.UA)[0] for a in short])
    plans = dict(none=np.zeros((T, n)), static=seq.static_plan(F, T, k), myopic=seq.myopic_plan(F, T, k),
                 seq_surrogate=P.X[int(np.argmin(Esur))].reshape(T, n), shortlist_oracle=P.X[short[int(np.argmin(ys))]].reshape(T, n))
    class _Sp: pass
    sp = _Sp(); sp.pairs = P.full_pairs; sp.dim = P.dim
    pr = A.anneal(sp, (Esur - Esur.mean()) / Esur.std(), np.full(len(P.full_pairs), 1e9), TA, dt=0.1)
    plans['seq_anneal_linear'] = P.X[int(np.argmax(pr))].reshape(T, n)

    per = {}
    for name, pl in plans.items():
        L = []
        for c in range(0, RB, 1000):
            U = UB[c:c + 1000]; R = U.shape[0]
            burning = np.zeros((R, n), bool); burning[:, F.src] = True; ever = burning.copy()
            for t in range(F.Tmax):
                prot = pl[t] if t < T else np.zeros(n)
                q = F.q * (1 - seq.ETA * prot)[None, :]
                new = (burning[:, :, None] & (U[:, t] < q[None])).any(1) & ~ever
                ever |= new; burning = new
                if not burning.any(): break
            L.append((ever * F.v).sum(1))
        per[name] = np.concatenate(L)
    b = per['none'].mean()
    saved = {k_: float(100 * (b - v.mean()) / b) for k_, v in per.items()}
    d = 100 * (per['myopic'] - per['seq_surrogate']) / b
    return dict(seed=sd, r2_out=float(r2_out), saved=saved, diff_sur_myo=float(d.mean()),
                diff_sur_myo_se=float(d.std(ddof=1) / np.sqrt(RB)),
                diff_ann_myo=float((100 * (per['myopic'] - per['seq_anneal_linear']) / b).mean()),
                diff_ora_sur=float((100 * (per['seq_surrogate'] - per['shortlist_oracle']) / b).mean()),
                same_plan_sur_ora=bool((plans['seq_surrogate'] == plans['shortlist_oracle']).all()),
                t=time.time() - t0)

if __name__ == '__main__':
    s0, s1, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
    res = []
    for sd in range(s0, s1):
        r = run(20, sd); res.append(r)
        print(sd, {k: round(v, 2) for k, v in r['saved'].items()}, 'sur-myo', round(r['diff_sur_myo'], 2), '+-', round(r['diff_sur_myo_se'], 2),
              'R2', round(r['r2_out'], 4), f"[{r['t']:.0f}s]", flush=True)
        json.dump(res, open(out, 'w'))

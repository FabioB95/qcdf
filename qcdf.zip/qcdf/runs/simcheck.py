"""Reviewer C1: reduced feasible-subspace simulator vs full-register Qiskit statevector (Dicke state via StatePreparation, RZZ/RZ phase separator, XXPlusYYGate(2*beta) mixer)."""
import sys, numpy as np, itertools
sys.path.insert(0, '../out')
from qcdf_scaling import DickeSpace, qaoa_state, random_instance
from qiskit import QuantumCircuit
from qiskit.circuit.library import XXPlusYYGate, StatePreparation
from qiskit.quantum_info import Statevector
out = []
for N in (6, 8):
    K = N // 2; rng = np.random.default_rng(N)
    for trial in range(5):
        h, ED = random_instance(N, rng); J = 0.3; p = 3
        x = np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)])
        sp = DickeSpace(N, K, ED); E = sp.energies(h, J); red = qaoa_state(x, sp, E)

        amp = np.zeros(2 ** N, complex)
        for a, z in enumerate(sp.Z): amp[sum(int(b) << q for q, b in enumerate(z))] = 1 / np.sqrt(sp.dim)
        qc = QuantumCircuit(N); qc.append(StatePreparation(amp), range(N))
        for g, b in zip(x[:p], x[p:]):

            for i in range(N): qc.rz(-g * h[i], i)
            for (i, j) in ED: qc.rzz(2 * g * J, i, j)
            for (i, j) in ED: qc.append(XXPlusYYGate(2 * b), [i, j])
        full = Statevector(qc).data
        idx = [sum(int(bb) << q for q, bb in enumerate(z)) for z in sp.Z]
        f = full[idx]; ph = np.vdot(f, red) / abs(np.vdot(f, red))
        leak = 1 - np.sum(np.abs(f) ** 2)
        out.append((N, trial, float(np.max(np.abs(f * ph - red))), float(leak)))
        print(out[-1], flush=True)
print('max |d amp| N=6:', max(o[2] for o in out if o[0] == 6), ' N=8:', max(o[2] for o in out if o[0] == 8), ' max leakage:', max(o[3] for o in out))

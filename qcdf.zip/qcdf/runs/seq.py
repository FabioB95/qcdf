"""Sequential QCDF: horizon-aware allocation with state propagation (wildfire CA)."""
import numpy as np, math, itertools, json, sys, time
from scipy.optimize import minimize

ETA = 0.85
HEX_DIRS = [(1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1)]

def hex_cells(n):
    cells = [(q, r) for q in range(-6, 7) for r in range(-6, 7)]
    key = lambda c: (abs(c[0]) + abs(c[1]) + abs(c[0] + c[1])) / 2 + 1e-3 * (c[0] * 7 + c[1])
    cells = sorted(cells, key=key)[:n]
    idx = {c: i for i, c in enumerate(cells)}
    edges = sorted({tuple(sorted((i, idx[(q + dq, r + dr)]))) for (q, r), i in idx.items()
                    for dq, dr in HEX_DIRS if (q + dq, r + dr) in idx})
    xy = np.array([(q + r / 2, r * math.sqrt(3) / 2) for q, r in cells])
    return xy, edges

class Fire:
    def __init__(s, n, rng, R=1000):
        s.n = n; s.xy, s.edges = hex_cells(n)
        s.v = rng.uniform(0.2, 1.0, n); s.f = rng.uniform(0.5, 0.95, n)
        wind = rng.uniform(0, 2 * np.pi); s.src = int(np.argmin(s.xy @ np.array([math.cos(wind), math.sin(wind)])))
        s.v[s.src] = 0.0
        s.q = np.zeros((n, n))
        for i, j in s.edges:
            for a, b in ((i, j), (j, i)):
                d = s.xy[b] - s.xy[a]; th = math.atan2(d[1], d[0])
                s.q[a, b] = min(0.97, s.f[b] * (0.55 + 0.35 * math.cos(th - wind)))
        s.Tmax = n + 1
        s.UA = rng.random((R, s.Tmax, n, n)); s.UB = rng.random((R, s.Tmax, n, n))

    def loss(s, plan, U):
        R = U.shape[0]; T = plan.shape[0]
        burning = np.zeros((R, s.n), bool); burning[:, s.src] = True
        ever = burning.copy()
        for t in range(s.Tmax):
            prot = plan[t] if t < T else np.zeros(s.n)
            q = s.q * (1 - ETA * prot)[None, :]
            ign = (burning[:, :, None] & (U[:, t] < q[None])).any(1)
            new = ign & ~ever
            ever |= new; burning = new
            if not burning.any(): break
        return float((ever * s.v).sum(1).mean()), ever.mean(0)

    def step_burn_prob(s, plan_prefix, U, t):
        R = U.shape[0]; burning = np.zeros((R, s.n), bool); burning[:, s.src] = True; ever = burning.copy()
        for tt in range(t + 1):
            prot = plan_prefix[tt] if tt < len(plan_prefix) else np.zeros(s.n)
            q = s.q * (1 - ETA * prot)[None, :]
            new = (burning[:, :, None] & (U[:, tt] < q[None])).any(1) & ~ever
            ever |= new; burning = new
        return burning, ever

def subsets(n, k):
    return [np.array([1 if i in c else 0 for i in range(n)]) for c in itertools.combinations(range(n), k)]

def static_plan(F, T, k):
    _, pburn = F.loss(np.zeros((T, F.n)), F.UA)
    score = F.v * pburn; score[F.src] = -1
    top = np.argsort(-score)[:k]; row = np.zeros(F.n); row[top] = 1
    return np.tile(row, (T, 1))

def myopic_plan(F, T, k):
    plan = []
    S = subsets(F.n, k)
    for t in range(T):
        best, bestrow = None, None
        for row in S:
            pp = np.array(plan + [row])

            R = F.UA.shape[0]; burning = np.zeros((R, F.n), bool); burning[:, F.src] = True; ever = burning.copy()
            for tt in range(t + 1):
                q = F.q * (1 - ETA * pp[tt])[None, :]
                new = (burning[:, :, None] & (F.UA[:, tt] < q[None])).any(1) & ~ever
                ever |= new; burning = new
            val = (burning * F.v).sum(1).mean()
            if best is None or val < best: best, bestrow = val, row
        plan.append(bestrow)
    return np.array(plan)

def features(X):
    M, d = X.shape; iu = np.triu_indices(d, 1)
    return np.hstack([np.ones((M, 1)), X, (X[:, :, None] * X[:, None, :])[:, iu[0], iu[1]]])

class ProductDicke:
    def __init__(s, n, k, T, edges):
        s.S = subsets(n, k); s.M = len(s.S); s.T = T; s.n = n
        Z = np.array(s.S); s.Z = Z
        key = {tuple(z): a for a, z in enumerate(Z)}
        s.pairs = []
        for i, j in edges:
            a01 = np.where((Z[:, i] == 0) & (Z[:, j] == 1))[0]
            a10 = []
            for a in a01:
                row = Z[a].copy(); row[i], row[j] = 1, 0; a10.append(key[tuple(row)])
            a10 = np.array(a10)
            s.pairs.append((a01, a10))
        s.dim = s.M ** T
        idx = np.array(list(itertools.product(range(s.M), repeat=T)))
        s.X = np.concatenate([Z[idx[:, t]] for t in range(T)], axis=1)

        s.full_pairs = []; s.pair_te = []
        for t in range(T):
            stride = s.M ** (T - 1 - t)
            for e, (a01, a10) in enumerate(s.pairs):
                m = -np.ones(s.M, int); m[a01] = a10
                A = np.where(m[idx[:, t]] >= 0)[0]
                s.full_pairs.append((A, A + (m[idx[A, t]] - idx[A, t]) * stride)); s.pair_te.append((t, e))

def seq_state(x, P, E, wts=None):
    p = len(x) // 2; psi = np.full(P.dim, 1 / math.sqrt(P.dim), complex)
    shape = (P.M,) * P.T
    for g, b in zip(x[:p], x[p:]):
        psi = psi * np.exp(-1j * g * E)
        psi = psi.reshape(shape)
        for t in range(P.T):
            psi = np.moveaxis(psi, t, 0)
            for e, (a01, a10) in enumerate(P.pairs):
                bb = b * (wts[t][e] if wts is not None else 1.0)
                cb, sb = math.cos(bb), math.sin(bb)
                x01, x10 = psi[a01].copy(), psi[a10].copy()
                psi[a01] = cb * x01 - 1j * sb * x10; psi[a10] = cb * x10 - 1j * sb * x01
            psi = np.moveaxis(psi, 0, t)
        psi = psi.reshape(-1)
    return psi

def run_instance(n, k, T, seed, p=3, restarts=12, M_fit=1500):
    rng = np.random.default_rng(seed); F = Fire(n, rng)
    P = ProductDicke(n, k, T, F.edges)
    t0 = time.time()

    LA = np.array([F.loss(P.X[a].reshape(T, n), F.UA)[0] for a in range(P.dim)])
    t_enum = time.time() - t0

    fit_idx = rng.choice(P.dim, min(M_fit, P.dim), replace=False)
    Phi = features(P.X[fit_idx].astype(float))
    coef, *_ = np.linalg.lstsq(Phi, LA[fit_idx], rcond=None)
    Esur = features(P.X.astype(float)) @ coef
    r2 = 1 - np.var(LA - Esur) / np.var(LA)

    f = lambda x: float(np.real(np.vdot(st := seq_state(x, P, Esur), Esur * st)))
    best = None
    for _ in range(restarts):
        x0 = np.concatenate([rng.uniform(0, 2 * np.pi / max(np.ptp(Esur), 1e-9), p), rng.uniform(0, np.pi, p)])
        r = minimize(f, x0, method='L-BFGS-B'); best = r if best is None or r.fun < best.fun else best
    pr = np.abs(seq_state(best.x, P, Esur)) ** 2
    a_q = int(np.argmax(pr)); a_s = int(np.argmin(Esur)); a_o = int(np.argmin(LA))
    plans = dict(none=np.zeros((T, n)), static=static_plan(F, T, k), myopic=myopic_plan(F, T, k),
                 seq_qcdf=P.X[a_q].reshape(T, n), seq_surrogate=P.X[a_s].reshape(T, n),
                 oracle=P.X[a_o].reshape(T, n))

    import anneal as A
    class _Sp: pass
    sp = _Sp(); sp.pairs = P.full_pairs; sp.dim = P.dim
    En = (Esur - Esur.mean()) / Esur.std()
    _, pb = F.loss(np.zeros((T, n)), F.UA)

    R_ = F.UA.shape[0]; burning = np.zeros((R_, n), bool); burning[:, F.src] = True; ever = burning.copy(); u_t = []
    for t in range(T):
        new = (burning[:, :, None] & (F.UA[:, t] < F.q[None])).any(1) & ~ever; ever |= new; burning = new
        pt = burning.mean(0); u_t.append(np.sqrt(pt * (1 - pt)))
    u_t = np.array(u_t); u_t = u_t / max(u_t.max(), 1e-9)
    ub = np.array([(u_t[t, F.edges[e][0]] + u_t[t, F.edges[e][1]]) / 2 + 0.05 for t, e in P.pair_te])
    for name, taus in dict(seq_anneal_linear=np.full(len(ub), 1e9), seq_anneal_u=0.35 * ub / ub.mean(),
                           seq_anneal_uniform=np.full(len(ub), 0.35)).items():
        pra = A.anneal(sp, En, taus, 40.0, dt=0.1)
        plans[name] = P.X[int(np.argmax(pra))].reshape(T, n)
        extra = locals().setdefault('extra', {}); extra[name] = float(pra[a_s])
    res = {name: F.loss(pl, F.UB)[0] for name, pl in plans.items()}

    return dict(n=n, k=k, T=T, seed=seed, dim=P.dim, r2=float(r2), t_enum=t_enum,
                p_opt_sur=float(pr[a_s]), modal_is_sur_opt=bool(a_q == a_s), p_opt_anneal=extra,
                amp=float(pr[a_s] * P.dim), loss=res,
                plans={kk: vv.astype(int).tolist() for kk, vv in plans.items()},
                coef=coef.tolist(), Esur_range=[float(Esur.min()), float(Esur.max())])

if __name__ == '__main__':
    out = []
    for n, k, T, seeds in [(10, 1, 4, range(int(sys.argv[1]), int(sys.argv[2])))]:
        for sd in seeds:
            t = time.time(); r = run_instance(n, k, T, 100 + sd); out.append(r)
            L = r['loss']; base = L['none']
            print(f"n={n} seed={sd} dim={r['dim']} R2={r['r2']:.3f} P_opt_sur={r['p_opt_sur']:.3f} ({r['amp']:.0f}x) "
                  + " ".join(f"{a}={100*(base-L[a])/base:.1f}%" for a in ['static', 'myopic', 'seq_qcdf', 'seq_anneal_linear', 'seq_anneal_u', 'seq_surrogate', 'oracle'])
                  + f"  [{time.time()-t:.0f}s]", flush=True)
            json.dump(out, open(sys.argv[3], 'w'))

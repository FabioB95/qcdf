"""Penalty-QUBO QAOA (X mixer, |+>^N) vs Dicke+XY QAOA on random hexagonal instances, N=10,12, k=N/2 (reviewer point A4). Same depth p, same number of random restarts, best run selected by energy <H_C> in both cases (no selection on P(opt))."""
import sys, json, itertools, numpy as np
from scipy.optimize import minimize
sys.path.insert(0, '../out')
from qcdf_scaling import random_instance, DickeSpace, qaoa_state, qaoa_energy, optimise_qaoa
J = 0.3
def penalty_run(N, K, h, ED, lam, p, R, rng):
    Z = np.array(list(itertools.product([0, 1], repeat=N))); s = 1 - 2 * Z
    Ed = Z @ h + sum(J * s[:, i] * s[:, j] for i, j in ED); w = Z.sum(1); feas = w == K
    opt = np.argmin(np.where(feas, Ed, np.inf)); Hc = Ed + lam * (w - K) ** 2
    def mix(psi, b):
        psi = psi.reshape([2] * N); c, sn = np.cos(b), -1j * np.sin(b)
        for q in range(N):
            psi = np.moveaxis(psi, q, 0); a0, a1 = psi[0].copy(), psi[1].copy()
            psi[0] = c * a0 + sn * a1; psi[1] = sn * a0 + c * a1; psi = np.moveaxis(psi, 0, q)
        return psi.reshape(-1)
    def state(x):
        psi = np.full(2 ** N, 2 ** (-N / 2), complex)
        for g, b in zip(x[:p], x[p:]): psi = mix(psi * np.exp(-1j * g * Hc), b)
        return psi
    f = lambda x: float(np.real(np.vdot(state(x), Hc * state(x))))
    best = None
    for _ in range(R):
        x0 = np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)])
        r = minimize(f, x0, method='L-BFGS-B', bounds=[(0, 2 * np.pi)] * p + [(0, np.pi)] * p)
        if best is None or r.fun < best.fun: best = r
    pr = np.abs(state(best.x)) ** 2; pf = pr[feas].sum()
    return dict(lam=lam, Pfeas=float(pf), Popt=float(pr[opt]), Popt_ps=float(pr[opt] / pf))
def dicke_run(N, K, h, ED, p, R, rng):
    sp = DickeSpace(N, K, ED); E = sp.energies(h, J); o = int(np.argmin(E)); best = None
    for _ in range(R):
        x0 = np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)])
        r = minimize(qaoa_energy, x0, args=(sp, E), method='L-BFGS-B', bounds=[(0, 2 * np.pi)] * p + [(0, np.pi)] * p)
        if best is None or r.fun < best.fun: best = r
    pr = np.abs(qaoa_state(best.x, sp, E)) ** 2
    bi = optimise_qaoa(sp, E, p, 10, rng)[p]; pi = np.abs(qaoa_state(bi.x, sp, E)) ** 2
    return dict(Popt=float(pr[o]), Punif=1 / sp.dim, Emean=float(best.fun), Popt_interp=float(pi[o]), Emean_interp=float(bi.fun),
                Estar=float(E[o]), Emax=float(E.max()))
if __name__ == '__main__':
    N = int(sys.argv[1]); out = sys.argv[2]; K = N // 2; p, R = 4, 20; res = []
    for inst in range(int(sys.argv[3]) if len(sys.argv) > 3 else 5):
        rng = np.random.default_rng(5000 + 100 * N + inst); h, ED = random_instance(N, rng)
        d = dicke_run(N, K, h, ED, p, R, rng)
        pen = [penalty_run(N, K, h, ED, lam, p, R, rng) for lam in [0.25, 0.5, 1, 2, 4, 8]]
        res.append(dict(N=N, inst=inst, dicke=d, penalty=pen))
        bp = max(pen, key=lambda x: x['Popt'])
        print(N, inst, 'dicke', round(d['Popt'], 3), 'interp', round(d['Popt_interp'], 3), 'best pen', round(bp['Popt'], 3), 'lam', bp['lam'], 'Pfeas range',
              round(min(x['Pfeas'] for x in pen), 3), round(max(x['Pfeas'] for x in pen), 3), flush=True)
        json.dump(res, open(out, 'w'))

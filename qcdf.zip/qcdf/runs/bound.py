"""Reviewer A5/C5: tightness of Prop. (linear bound) eps <= 2||H||/lambda. Exact ground state of H_phys + lambda*Pi_V (Pi_V = projector on Hamming weight != k) for the astronomical pilot (N=6, k=3) and a random N=8 instance, with the tunnelling strength delta = 0.1 (paper) and delta = 1.0."""
import sys, json, itertools, numpy as np
sys.path.insert(0, '../out'); sys.path.insert(0, '.')
from qcdf_scaling import random_instance
import pilot
def build(h, ED, u, J, delta):
    N = len(h); Z = np.array(list(itertools.product([0, 1], repeat=N))); s = 1 - 2 * Z
    diag = Z @ h + sum(J * s[:, i] * s[:, j] for i, j in ED)
    H = np.diag(diag).astype(float)
    for q in range(N):
        flip = np.arange(2 ** N) ^ (1 << (N - 1 - q))
        H[np.arange(2 ** N), flip] += -delta * u[q]
    return H, Z.sum(1), diag
res = []
cases = [('pilot', pilot.h, pilot.ED, pilot.u, 3)]
rng = np.random.default_rng(8); h8, ED8 = random_instance(8, rng); u8 = rng.random(8)
cases.append(('random N=8', h8, ED8, u8, 4))
for name, h, ED, u, k in cases:
    for delta in (0.1, 1.0):
        H, w, diag = build(h, ED, u, 0.3, delta); nH = np.max(np.abs(np.linalg.eigvalsh(H)))
        Pi = np.diag((w != k).astype(float)); F = np.diag((w == k).astype(float))
        V = np.linalg.norm(Pi @ H @ F, 2); Hd = np.max(np.abs(diag))
        for lam in np.logspace(-1, 3, 25):
            ev, vec = np.linalg.eigh(H + lam * Pi); g = vec[:, 0]
            eps = float(g @ Pi @ g)
            res.append(dict(case=name, delta=delta, lam=float(lam), eps=eps, bound=float(2 * nH / lam), normH=float(nH), V=float(V), Hdiag=float(Hd)))
        r = [x for x in res if x['case'] == name and x['delta'] == delta]
        big = [x for x in r if x['lam'] >= 10]
        print(name, delta, '||H||', round(nH, 3), '||PiHF||', round(V, 3), ' ratio bound/eps at lam=10,100,1000:',
              [round(x['bound'] / max(x['eps'], 1e-300), 1) for x in r if round(np.log10(x['lam']), 3) in (1.0, 2.0, 3.0)],
              ' fitted slope log eps vs log lam (lam>=10):', round(np.polyfit(np.log([x['lam'] for x in big]), np.log([x['eps'] for x in big]), 1)[0], 3))
json.dump(res, open('bound.json', 'w'))

"""Referee checks on the wildfire hindcast (active phase, K=10)."""
import sys, os, json, numpy as np
_ARGV = list(sys.argv); sys.argv = ['x']
import fullscale as FS
sys.argv = _ARGV
DATES = ['2021-07-24', '2021-07-25', '2021-07-27', '2021-07-28', '2021-07-29', '2021-07-30', '2021-07-31', '2021-08-01', '2021-08-04', '2021-08-05']
METH = ['QCDF_MILP', 'QCDF_h_only', 'B4_value_at_risk', 'CELF_greedy']

def plans():
    src = {'prospective': json.load(open('fsP_act.json')), 'rolling': json.load(open('fsR.json')), 'oracle': json.load(open('fs_a.json')) + json.load(open('fs_b.json'))}
    return {m: {r['T0']: {k: r['K']['10']['eval'][k]['plan'] for k in METH if k in r['K']['10']['eval']} for r in R if r['T0'] in DATES} for m, R in src.items()}

if __name__ == '__main__':
    mode, out = sys.argv[1], sys.argv[2]; res = []
    if mode == 'xeval':
        PL = plans(); model = os.environ['QCDF_MODEL']
        for d in DATES:
            P = FS.Problem(d); base = P.L(set(), FS.R_B, 99).mean(); row = dict(T0=d, eval_model=model)
            loc = {str(FS.G.h3.iloc[P.D.cells[i]]): i for i in range(P.n)}
            for m, byd in PL.items():
                for k, S in byd.get(d, {}).items(): row[f'{m}|{k}'] = float(100 * (base - P.L({loc[c] for c in S if c in loc}, FS.R_B, 99).mean()) / base); row[f'{m}|{k}|n'] = sum(c in loc for c in S)
            res.append(row); json.dump(res, open(out, 'w')); print(d, model, flush=True)
    else:
        for d in DATES:
            P = FS.Problem(d).build_qubo(); base = P.L(set(), FS.R_B, 99).mean(); val = lambda S: float(100 * (base - P.L(set(S), FS.R_B, 99).mean()) / base)
            Zm, _ = P.milp(10); Em = P.energy(Zm); Z = []
            for _ in range(10):
                cand = [int(i) for i in P.elig if int(i) not in Z]
                Z.append(min(cand, key=lambda i: P.energy(Z + [i])))
            Jrow = {}
            for (i, j), v in P.J.items(): Jrow[i] = Jrow.get(i, 0.0) + v; Jrow[j] = Jrow.get(j, 0.0) + v
            mono = float(np.mean([-P.h[i] >= Jrow.get(int(i), 0.0) - 1e-12 for i in P.elig]))
            res.append(dict(T0=d, E_milp=float(Em), E_sgreedy=float(P.energy(Z)), v_milp=val(Zm), v_sgreedy=val(Z), overlap=len(set(Z) & set(Zm)), monotone_frac=mono))
            json.dump(res, open(out, 'w')); print(res[-1], flush=True)

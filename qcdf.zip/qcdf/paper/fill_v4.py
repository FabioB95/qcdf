import json, glob, numpy as np
from scipy.stats import wilcoxon
R = []
for f in sorted(glob.glob('../runs/seq_*.json')): R += json.load(open(f))
S = {k: np.array([100 * (r['loss']['none'] - r['loss'][k]) / r['loss']['none'] for r in R]) for k in
     ['static', 'myopic', 'seq_qcdf', 'seq_anneal_linear', 'seq_anneal_u', 'seq_surrogate', 'oracle']}
def cnt(a, b):
    d = S[a] - S[b]; return (d > 0.05).sum(), (abs(d) <= 0.05).sum(), (d < -0.05).sum(), wilcoxon(d).pvalue
sb, st, sw, sp = cnt('seq_surrogate', 'myopic'); ab, at, aw, ap = cnt('seq_anneal_linear', 'myopic')
ub, _, uw, _ = cnt('seq_anneal_u', 'seq_anneal_linear')
fmtp = lambda p: f"{p:.3f}" if p >= 0.001 else r"<0.001"
rep = {'NI': len(R), 'R2': f"{min(r['r2'] for r in R):.3f}",
       'SUR': f"{S['seq_surrogate'].mean():.1f}", 'MYO': f"{S['myopic'].mean():.1f}", 'STA': f"{S['static'].mean():.1f}",
       'ORA': f"{S['oracle'].mean():.1f}", 'SURREG': f"{(S['oracle'] - S['seq_surrogate']).mean():.1f}",
       'SURB': sb, 'SURT': st, 'SURW': sw, 'SURP': fmtp(sp),
       'ANL': f"{S['seq_anneal_linear'].mean():.1f}", 'ANLREG': f"{(S['oracle'] - S['seq_anneal_linear']).mean():.1f}",
       'ANLB': ab, 'ANLT': at, 'ANLW': aw, 'ANLP': fmtp(ap),
       'QAO': f"{S['seq_qcdf'].mean():.1f}", 'QAOP': f"{100 * np.mean([r['p_opt_sur'] for r in R]):.1f}",
       'ANU': f"{S['seq_anneal_u'].mean():.1f}", 'ULB': ub, 'ULW': uw,
       'ANUP': f"{100 * np.mean([r['p_opt_anneal']['seq_anneal_u'] for r in R]):.0f}",
       'ANLP2': f"{100 * np.mean([r['p_opt_anneal']['seq_anneal_linear'] for r in R]):.0f}"}
s = open('v4_body.tex').read()
for k, v in rep.items(): s = s.replace(f'@@{k}@@', str(v))
import re as _re
assert not [m for m in _re.findall(r'@@([A-Z0-9]+)@@', s) if not m.startswith(('B','X'))]
open('v4_body_filled.tex', 'w').write(s)
print(rep)

# ---- large-scale sequential (N=20)
B = []
for f in sorted(glob.glob('../runs/big_*.json')): B += json.load(open(f))
if B:
    SB = {k: np.array([100 * (r['loss']['none'] - r['loss'][k]) / r['loss']['none'] for r in B]) for k in
          ['static', 'myopic', 'seq_anneal_linear', 'seq_anneal_u', 'seq_surrogate', 'oracle']}
    d = SB['seq_surrogate'] - SB['myopic']
    p = wilcoxon(d).pvalue if np.any(d != 0) else 1.0
    rb = {'BNI': len(B), 'BR2': f"{min(r['r2_out'] for r in B):.4f}", 'BSTA': f"{SB['static'].mean():.1f}",
          'BMYO': f"{SB['myopic'].mean():.1f}", 'BSUR': f"{SB['seq_surrogate'].mean():.1f}",
          'BSURB': int((d > 0.05).sum()), 'BSURT': int((abs(d) <= 0.05).sum()), 'BSURW': int((d < -0.05).sum()),
          'BSURP': fmtp(p), 'BORA': f"{SB['oracle'].mean():.1f}", 'BANL': f"{SB['seq_anneal_linear'].mean():.1f}",
          'BANU': f"{SB['seq_anneal_u'].mean():.1f}",
          'BANLREG': f"{(SB['oracle'] - SB['seq_anneal_linear']).mean():.1f}",
          'BANUREG': f"{(SB['oracle'] - SB['seq_anneal_u']).mean():.1f}"}
    s = open('v4_body_filled.tex').read()
    for k, v in rb.items(): s = s.replace(f'@@{k}@@', str(v))
    import re as _r2; assert not [m for m in _r2.findall(r'@@(\w+)@@', s) if not m.startswith('X')]
    open('v4_body_filled.tex', 'w').write(s); print(rb)

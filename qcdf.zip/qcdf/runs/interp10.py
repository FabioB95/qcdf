"""Adds INTERP warm-started constraint-preserving QAOA runs to the N=10 penalty comparison."""
import sys, json, numpy as np
sys.path.insert(0, '../out')
from qcdf_scaling import random_instance, DickeSpace, qaoa_state, optimise_qaoa
R = json.load(open('pen10.json'))
for r in R:
    N = r['N']; rng = np.random.default_rng(5000 + 100 * N + r['inst']); h, ED = random_instance(N, rng)
    sp = DickeSpace(N, N // 2, ED); E = sp.energies(h, 0.3); o = int(np.argmin(E))
    bi = optimise_qaoa(sp, E, 4, 10, np.random.default_rng(99 + r['inst']))[4]
    r['dicke']['Popt_interp'] = float((np.abs(qaoa_state(bi.x, sp, E)) ** 2)[o]); r['dicke']['Emean_interp'] = float(bi.fun)
    print(r['inst'], r['dicke'], flush=True)
json.dump(R, open('pen10.json', 'w'))

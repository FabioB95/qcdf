"""Fill the tokens of the reviewer-driven experiments (penalty N=10/12, SA budget, N=20 with a larger ensemble) into ../paper/v4_body_filled.tex. Run after fill_v4.py and real/gen_real.py."""
import json, glob, re, numpy as np
from scipy.stats import wilcoxon
tok = {}

P = []
for f in ('pen10.json', 'pen12.json'): P += json.load(open(f))
rows = []; wins = 0
for N in (10, 12):
    X = [r for r in P if r['N'] == N]
    d = np.array([r['dicke']['Popt'] for r in X])
    di = np.array([r['dicke'].get('Popt_interp', np.nan) for r in X])
    bp = [max(r['penalty'], key=lambda x: x['Popt']) for r in X]
    pp = np.array([b['Popt'] for b in bp]); pf = np.array([b['Pfeas'] for b in bp]); pps = np.array([b['Popt_ps'] for b in bp])
    lam = sorted(set(b['lam'] for b in bp)); un = X[0]['dicke']['Punif']
    wins += int((pp > np.fmax(d, np.nan_to_num(di))).sum())
    dis = f"{100*np.nanmean(di):.2f}" if np.isfinite(di).any() else '--'
    rows.append(f"{N} & {len(X)} & ${100*un:.2f}$ & ${100*d.mean():.2f}$ & ${dis}$ & ${100*pp.mean():.2f}$ & ${100*pf.mean():.0f}$ & ${100*pps.mean():.2f}$ & {', '.join(f'{l:g}' for l in lam)} \\\\")
    tok[f'XPEN{N}_D'] = f"{100*d.mean():.2f}"; tok[f'XPEN{N}_P'] = f"{100*pp.mean():.2f}"; tok[f'XPEN{N}_PS'] = f"{100*pps.mean():.2f}"
    tok[f'XPEN{N}_F'] = f"{100*pf.mean():.0f}"; tok[f'XPEN{N}_DI'] = f"{100*np.nanmean(di):.2f}"; tok[f'XPEN{N}_n'] = str(len(X))
ntot = len(P)
tok['XPENBIG'] = r"""
\paragraph{Larger instances.} The pilot has only 20 feasible states. We
repeated the comparison on random hexagonal instances (scalars uniform on
$[0,1]$, $J=0.3$, $k=N/2$) at $N=10$ and $N=12$, with the same depth
($p=4$), the same number of random restarts (20) and the same selection
rule (lowest energy) for both encodings, and $\lambda\in\{0.25,0.5,1,2,4,8\}$
for the penalty (Table~\ref{tab:penbig}). The pilot result does not carry
over. With the best $\lambda$ of the scan --- chosen with knowledge of the
optimum, which favours the penalty encoding --- the penalty runs place more
probability on the optimum than the constraint-preserving runs in """ + f"{wins} of {ntot}" + r""" instances
(mean @@XPEN10_P@@\% against @@XPEN10_D@@\% with random restarts and @@XPEN10_DI@@\%
with INTERP warm start at $N=10$; @@XPEN12_P@@\% against @@XPEN12_D@@\% and @@XPEN12_DI@@\% at $N=12$), at a feasibility of only @@XPEN10_F@@--@@XPEN12_F@@\%,
and the best $\lambda$ is small at $N=10$ (0.25--0.5) and spread over the scan at $N=12$. At these sizes
both encodings at $p=4$ are within a small factor of uniform sampling, so
the advantage of the constraint-preserving ansatz reduces to what it
guarantees by construction: every sample is feasible, and there is no
$\lambda$ to tune.

"""
tok['XPENBIGTAB'] = r"""\begin{table}[h]
\centering
\caption{Penalty versus constraint-preserving QAOA on random instances
($p=4$, 20 random restarts each, lowest-energy run). Probabilities in \%,
means over instances of each column (so $P(\mathrm{opt}|\mathrm{feas})$ is the mean of the per-instance ratios, not the ratio of the mean columns). Dicke: random restarts; INTERP: warm-started by interpolation
(Section~\ref{sec:solver}). Penalty: best $\lambda$ of the
scan for each instance; $P(\mathrm{feas})$ and the post-selected
$P(\mathrm{opt}\,|\,\mathrm{feas})$ at that $\lambda$.}
\label{tab:penbig}
\footnotesize
\begin{tabular}{rrccccccc}
\toprule
$N$ & inst. & uniform $\feasible_k$ & Dicke & Dicke INTERP & penalty & $P(\mathrm{feas})$ & $P(\mathrm{opt}|\mathrm{feas})$ & best $\lambda$ \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
"""
tok['XPENABS'] = r"but beyond the 20-state pilot a tuned penalty encoding reaches a higher probability of the optimum"
tok['XPENCONTRIB'] = (r"at $N=10$--$12$, by contrast, a tuned penalty encoding reaches a higher probability of the optimum. "
                      r"The two encodings therefore differ in kind: the constraint-preserving one guarantees exact feasibility with "
                      r"nothing to tune at every size, while their relative solution quality depends on size")
tok['XSUMPEN'] = r"pilot: Dicke $2\times$ penalty; $N=10$--$12$: penalty higher $P(\mathrm{opt})$, Dicke always feasible"

S = json.load(open('sa_budget.json')); k = {int(a): v for a, v in S['kappa'].items() if np.isfinite(v)}
tok["XSAKAPPA"] = "$" + f"{S['kappa_opt']:.2f}" + "$ (best budget)"
tok['XSATEXT'] = (r"The exponent of simulated annealing is not an artefact of the 5-sweep budget. On 20 fresh instances per $N$, fixed "
    r"budgets of " + ", ".join(f"{a}" for a in k) + r" sweeps give $\kappa=" + "$, $".join(f"{v:.2f}" for v in k.values()) +
    r"$ respectively (with 1 sweep the success probability is zero on some instances; with 20--100 sweeps it approaches one, "
    r"and the time-to-solution then grows only with the budget $S N$), and taking the best budget at each $N$ gives "
    r"$\kappa=" + f"{S['kappa_opt']:.2f}" + r"$. The 5-sweep value used in Figure~\ref{fig:tts} is therefore, if anything, "
    r"favourable to QAOA.")

B = []
for f in sorted(glob.glob('big2_[ab].json')): B += json.load(open(f))
B = sorted(B, key=lambda r: r['seed']); n = len(B)
d = np.array([r['diff_sur_myo'] for r in B]); se = np.array([r['diff_sur_myo_se'] for r in B])
sig = int(((d - 1.96 * se) > 0).sum()); neg = int(((d + 1.96 * se) < 0).sum())
da = np.array([r['diff_ann_myo'] for r in B]); same = sum(r['same_plan_sur_ora'] for r in B)
sv = {k: np.mean([r['saved'][k] for r in B]) for k in B[0]['saved']}
p = wilcoxon(d).pvalue
tok['XBIG2TEXT'] = (r"To resolve them we repeated the $N=20$ study with a four times larger decision ensemble "
    r"(2000 realisations; surrogate fitted on 6000 plans, holdout $R^2\ge" + f"{min(r['r2_out'] for r in B):.4f}" + r"$) and 5000 evaluation "
    r"realisations, which give a paired standard error per instance. The ordering is unchanged --- static " + f"{sv['static']:.1f}" +
    r"\%, myopic " + f"{sv['myopic']:.1f}" + r"\%, sequential surrogate " + f"{sv['seq_surrogate']:.1f}" + r"\%, anneal " +
    f"{sv['seq_anneal_linear']:.1f}" + r"\% --- and the margin of the surrogate plan over the myopic greedy is now resolved: $" +
    f"{d.mean():.2f}" + r"$ points on average (range $" + f"{d.min():.2f}" + r"$ to $" + f"{d.max():.2f}" + r"$), positive "
    r"beyond two standard errors in " + f"{sig}" + r" of " + f"{n}" + r" instances" + (f" and negative in {neg}" if neg else "") +
    r" (Wilcoxon $p=" + f"{p:.4f}" + r"$). Re-evaluating the 300 best plans of the surrogate on the decision ensemble and keeping the best changes the "
    r"plan in " + f"{n - same}" + r" of " + f"{n}" + r" instances and adds only $" + f"{np.mean([r['diff_ora_sur'] for r in B]):.2f}" +
    r"$ points on fresh realisations (it is worse in " + f"{sum(r['diff_ora_sur'] < -0.05 for r in B)}" + r"), so the surrogate plan is "
    r"essentially the best plan the decision ensemble can identify; the horizon gain over the myopic greedy at this scale is real "
    r"but modest, about one point on average and up to four.")
tok['XSUMSEQ'] = (r"seq.\ surrogate $>$ myopic by $" + f"{d.mean():.1f}" + r"$ pts at $N=20$ ($" + f"{sig}/{n}" +
                  r"$ instances beyond $2\sigma$); static far behind; QAOA $p=3$ below myopic")
json.dump(tok, open('extra_tokens.json', 'w'), indent=1)
fn = '../paper/v4_body_filled.tex'; s = open(fn).read()
for _ in range(2):
    for k_, v in sorted(tok.items(), key=lambda kv: -len(kv[0])): s = s.replace('@@' + k_ + '@@', v)
open(fn, 'w').write(s)
print('unfilled', sorted(set(re.findall(r'@@(\w+)@@', s))))
for k_, v in tok.items():
    if len(v) < 400: print(k_, '=', v)

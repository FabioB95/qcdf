#!/bin/bash
# full pipeline: tokens -> tex -> pdf (v14)
set -e
cd "$(dirname "$0")"
python3 make_v13.py
python3 fill_v4.py >/dev/null
(cd ../real && python3 gen_real.py 2021-08-04 > gen.log 2>&1)
(cd ../runs && python3 gen_extra.py > ../paper/gen_extra.log 2>&1)
(cd ../real && python3 gen_full.py > ../paper/gen_full.log 2>&1 && python3 gen_v8.py > ../paper/gen_v8.log 2>&1 && python3 gen_pert.py > ../paper/gen_pert.log 2>&1)
(cd ../astro && python3 gen_astro.py > ../paper/gen_astro.log 2>&1)
(cd ../real && python3 gen_qlns.py > ../paper/gen_qlns.log 2>&1 && python3 gen_q.py > ../paper/gen_q.log 2>&1 && python3 gen_fwd.py > ../paper/gen_fwd.log 2>&1 && python3 gen_v11.py > ../paper/gen_v11.log 2>&1 && python3 gen_v12.py > ../paper/gen_v12.log 2>&1 && python3 gen_v13.py > ../paper/gen_v13.log 2>&1 && python3 gen_qres.py > ../paper/gen_qres.log 2>&1 && python3 gen_v14.py > ../paper/gen_v14.log 2>&1 && python3 gen_v15.py > ../paper/gen_v15.log 2>&1 && python3 gen_qres2.py > ../paper/gen_qres2.log 2>&1)
grep -h unfilled gen_v8.log
python3 relabel.py
python3 build_v4.py >/dev/null
sed 's/QCDF_v4/QCDF_v15/g' QCDF_v4.tex > QCDF_v15.tex
pdflatex -interaction=nonstopmode QCDF_v15.tex >/dev/null || true
bibtex QCDF_v15 >/dev/null || true
pdflatex -interaction=nonstopmode QCDF_v15.tex >/dev/null || true
pdflatex -interaction=nonstopmode QCDF_v15.tex >/dev/null || true
grep -n "^!\|undefined\|Overfull" QCDF_v15.log | head || true
pdfinfo QCDF_v15.pdf | grep Pages
pdftotext QCDF_v15.pdf - | grep -c "@@" || true

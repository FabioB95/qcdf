"""Resource sensitivity on the decision-time Dixie domain: number of protected cells K x protection effectiveness eta."""
import sys, json, time, numpy as np
import fullscale as FS
import pandas as pd
from fastsim import _sim
RC = FS.RC

class PCond(FS.Problem):
    """Effectiveness that falls with wind speed and slope (Table S of operational checks): 0.85 / (1 + (v/6)^2) * (1 - 0.5 min(1, s/0.3))."""
    def __init__(s, T0, *a, **k):
        super().__init__(T0, *a, **k)
        days = [RC.mday[s.T0 + pd.Timedelta(days=t)] for t in range(s.sim.H)]
        v = np.stack([RC.met['vs'][d, s.D.cells] for d in days]); sl = np.zeros(s.n)
        for q, g in enumerate(s.D.cells): sl[q] = max([abs(RC.elev[j] - RC.elev[g]) / 2400 for j in FS.NB[g]] + [0])
        s.eta_mat = 0.85 / (1 + (v / 6.0) ** 2) * (1 - 0.5 * np.minimum(1, sl / 0.3))[None]
        s.eta = s.eta_mat.mean(1)
    def L(s, S, R, stream):
        S = set(S) | s.S_prev
        P = np.zeros((s.sim.H, s.n)); idx = np.fromiter(S, np.int64) if S else np.zeros(0, np.int64)
        P[:, idx] = s.eta_mat[:, idx]; Lr = np.zeros(R); F = np.zeros(s.n, np.int64)
        _sim(s.sim.src, s.sim.dst, s.sim.q, s.sim.b0, s.sim.v, P, 0.0, R, stream, Lr, F); return Lr

KS = (10, 20, 40, 80)
ETAS = [(0.85, 'const'), (0.5, 'const'), (0.3, 'const'), (0.85, 'weather'), (0.85, 'cond')]

def pool_for(K):
    return max(120, 3 * K)

def run(d, eta, mode):
    rows = []
    for pool in sorted({pool_for(K) for K in KS}):
        FS.M_PAIR = pool
        t0 = time.time(); P = (PCond(d) if mode == 'cond' else FS.Problem(d, eta, mode)).build_qubo()
        for K in [k for k in KS if pool_for(k) == pool]:
            if K > len(P.elig): continue
            plans = P.baselines(K)
            plans['QCDF_MILP'], res = P.milp(K); plans['QCDF_h_only'], _ = P.milp(K, use_J=False)
            plans['CELF_greedy'], ev = P.celf(K)
            E = P.evaluate(plans)
            rows.append(dict(T0=d, eta=eta, mode=mode, eta_mean=float(np.mean(P.eta_mat) if mode == 'cond' else np.mean(P.eta)), K=K, pool=pool, n_elig=int(len(P.elig)),
                             n_J=len(P.J), milp_status=int(res.status), none=E['_none']['loss'],
                             saved={k: v['saved'] for k, v in E.items() if not k.startswith('_')},
                             saved_pct={k: v['saved_pct'] for k, v in E.items() if not k.startswith('_')},
                             se={k: v['se'] for k, v in E.items() if not k.startswith('_')},
                             overlap_milp_honly=len(set(plans['QCDF_MILP']) & set(plans['QCDF_h_only'])),
                             overlap_milp_celf=len(set(plans['QCDF_MILP']) & set(plans['CELF_greedy']))))
            r = rows[-1]['saved_pct']
            print(d, eta, mode, K, f"pool={pool} J={len(P.J)} " + ' '.join(f"{k}={v:.1f}" for k, v in r.items()), f"[{time.time()-t0:.0f}s]", flush=True)
    return rows

if __name__ == '__main__':
    dates = sys.argv[1].split(','); outf = sys.argv[2]
    sel = [ETAS[int(i)] for i in sys.argv[3].split(',')] if len(sys.argv) > 3 else ETAS
    res = []
    for d in dates:
        for eta, mode in sel:
            res += run(d, eta, mode); json.dump(res, open(outf, 'w'))

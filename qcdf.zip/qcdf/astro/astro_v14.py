"""Referee checks on the sky campaigns (main DR3->DR4 and replication DR2->DR3)."""
import json, numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from scipy.special import logit
import astro_full as AF

def campaign(TR, TE, suf):
    rng = np.random.default_rng(7)
    d2, n2, X2, y2 = AF.transition(*TR); d3, n3, X3, y3 = AF.transition(*TE)
    ok2 = np.isfinite(X2).all(1); ok3 = np.isfinite(X3).all(1)
    sc = StandardScaler().fit(X2[ok2]); M = LogisticRegression(C=0.3, max_iter=2000).fit(sc.transform(X2[ok2]), y2[ok2])
    P3 = np.full(len(X3), y2[ok2].mean()); P3[ok3] = M.predict_proba(sc.transform(X3[ok3]))[:, 1]
    _, nb, cb = AF.load(TE[1]); mb = dict(zip(nb, cb))
    cls = {}
    for n, y in zip(n3, y3):
        if y: c = str(mb[n]).strip(); cls[c] = cls.get(c, 0) + 1
    missing = int(sum(1 for n in n3 if n not in mb))
    S = AF.Sky(d3, P3, rng); y = y3.astype(bool)
    R = json.load(open(f'astro_full_prospective{suf}.json'))
    out = dict(classes=cls, missing_in_later=missing, n_targets=int(len(y3)), n_pos=int(y.sum()), K={})
    rb = np.random.default_rng(3); pos = np.where(y)[0]; neg = np.where(~y)[0]
    aucs, slopes = [], []
    lp = logit(np.clip(P3, 1e-6, 1 - 1e-6))
    for _ in range(2000):
        idx = np.r_[rb.choice(pos, len(pos)), rb.choice(neg, len(neg))]
        aucs.append(roc_auc_score(y[idx], P3[idx])); slopes.append(LogisticRegression(C=1e6).fit(lp[idx][:, None], y[idx]).coef_[0, 0])
    out['auc'] = [float(roc_auc_score(y, P3)), *np.percentile(aucs, [2.5, 97.5]).tolist()]
    out['auc_curv'] = float(roc_auc_score(y, X3[:, 2])); out['slope_ci'] = np.percentile(slopes, [2.5, 97.5]).tolist()
    for K in ('20', '50', '200'):
        plans = {k: [S.loc[c] for c in Z if c in S.loc] for k, Z in R['K'][K]['plans'].items()}
        def cov(Z, thr):
            Zs = np.zeros(S.n, bool); Zs[Z] = True
            return np.array([bool(len(r)) and bool((v[Zs[r]] > thr).any()) for r, v in zip(S.rows, S.vals)])
        res = {}
        for k, Z in plans.items():
            if k == 'random': continue
            res[k] = {f't{t}': int((cov(Z, t) & y).sum()) for t in (0.01, 0.1, 0.5)}
        rr = np.random.default_rng(int(K)); rd = [int((cov(list(rr.choice(S.n, int(K), replace=False)), 0.01) & y).sum()) for _ in range(1000)]
        res['random'] = dict(t0_01_mean=float(np.mean(rd)), t0_01_sd=float(np.std(rd)))
        cq = cov(plans['QCDF_MILP'], 0.01)
        for k in ('most_curved', 'brightest', 'QCDF_h_only'):
            ck = cov(plans[k], 0.01); dd = []
            for _ in range(4000):
                idx = np.r_[rb.choice(pos, len(pos)), rb.choice(neg, len(neg))]
                dd.append(int((cq[idx] & y[idx]).sum()) - int((ck[idx] & y[idx]).sum()))
            res[k]['diff_ci'] = np.percentile(dd, [2.5, 97.5]).tolist()
        Zg = plans['greedy_exact']; Fg = S.F(Zg); Zs = set(Zg)
        gains = sorted((S.F(Zg + [i]) - Fg for i in range(S.n) if i not in Zs), reverse=True)[:int(K)]
        res['bound'] = dict(F_greedy=Fg, F_milp=S.F(plans['QCDF_MILP']), upper=Fg + float(sum(gains)))
        out['K'][K] = res; print(suf or 'main', K, res, flush=True)
    return out

if __name__ == '__main__':
    o = dict(main=campaign(['gll_psc_v27.fit', 'gll_psc_v31.fit'], ['gll_psc_v31.fit', 'gll_psc_v35.fit'], ''),
             rep=campaign(['gll_psc_v22.fit', 'gll_psc_v27.fit'], ['gll_psc_v27.fit', 'gll_psc_v31.fit'], '_rep'))
    json.dump(o, open('astro_v14.json', 'w'), indent=1)

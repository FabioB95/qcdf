"""Writes the HEALPix sky map of the pilot pixels in Galactic Mollweide projection as a TikZ figure."""
import healpy as hp, numpy as np
from scipy.optimize import brentq
rot=hp.Rotator(coord=['C','G'])
def moll(l,b):
    lam=np.radians(-(l)); phi=np.radians(b)
    th=np.empty_like(phi)
    for k,ph in enumerate(phi):
        if abs(abs(ph)-np.pi/2)<1e-9: th[k]=np.sign(ph)*np.pi/2; continue
        f=lambda t:2*t+np.sin(2*t)-np.pi*np.sin(ph)
        th[k]=brentq(f,-np.pi/2,np.pi/2)
    x=2*np.sqrt(2)/np.pi*lam*np.cos(th); y=np.sqrt(2)*np.sin(th)
    return x,y
SEL=[3,5,10]; PIL=[0,3,5,7,9,10]; S=1.9
out=[r"\begin{tikzpicture}[x=%.2fcm,y=%.2fcm]"%(S,S)]
out.append(r"\begin{scope}\clip (0,0) ellipse ({2*sqrt(2)} and {sqrt(2)});")
for p in PIL:
    v=hp.boundaries(1,p,step=40).T
    th,ph=rot(*hp.vec2ang(v))
    l=np.degrees(np.unwrap(ph)); b=90-np.degrees(th)
    l=l-360*np.round(np.mean(l)/360)
    style = "fill=qsel" if p in SEL else "fill=qpil"
    for sh in (-360,0,360):
        x,y=moll(l+sh,b)
        out.append(r"\path[%s] "%style+" -- ".join("(%.3f,%.3f)"%(a,c) for a,c in zip(x,y))+" -- cycle;")
for p in range(12):
    v=hp.boundaries(1,p,step=40).T
    th,ph=rot(*hp.vec2ang(v))
    l=((np.degrees(ph)+180)%360)-180; b=90-np.degrees(th)
    l=np.append(l,l[0]); b=np.append(b,b[0])
    x,y=moll(l,b)
    seg=[(x[0],y[0])]
    for k in range(1,len(x)):
        if abs(l[k]-l[k-1])>180:
            if len(seg)>1: out.append(r"\draw[line width=0.4pt] "+" -- ".join("(%.3f,%.3f)"%q for q in seg)+";")
            seg=[]
        seg.append((x[k],y[k]))
    if len(seg)>1: out.append(r"\draw[line width=0.4pt] "+" -- ".join("(%.3f,%.3f)"%q for q in seg)+";")
out.append(r"\end{scope}")

for B in [-60,-30,30,60]:
    x,y=moll(np.linspace(-179.9,179.9,60),np.full(60,B)); out.append(r"\draw[gray!60,densely dotted] "+" -- ".join("(%.3f,%.3f)"%(a,c) for a,c in zip(x,y))+";")
x,y=moll(np.linspace(-179.9,179.9,60),np.zeros(60)); out.append(r"\draw[red!70!black,thick,dashed] "+" -- ".join("(%.3f,%.3f)"%(a,c) for a,c in zip(x,y))+";")
for L in [-120,-60,0,60,120]:
    x,y=moll(np.full(40,L),np.linspace(-89.9,89.9,40)); out.append(r"\draw[gray!60,densely dotted] "+" -- ".join("(%.3f,%.3f)"%(a,c) for a,c in zip(x,y))+";")
out.append(r"\draw[thick] (0,0) ellipse ({2*sqrt(2)} and {sqrt(2)});")
for p in range(12):
    th,ph=rot(*hp.pix2ang(1,p)); l=np.degrees(ph); l=((l+180)%360)-180; b=90-np.degrees(th)
    x,y=moll(np.array([l]),np.array([b]))
    out.append(r"\node[font=\scriptsize%s] at (%.3f,%.3f) {%d};"%(r"\bfseries" if p in PIL else r",gray",x[0],y[0],p))
out.append(r"\node[font=\scriptsize,anchor=west] at ({2*sqrt(2)+0.05},0) {$l=-180^\circ$};")
out.append(r"\node[font=\scriptsize,anchor=east] at ({-2*sqrt(2)-0.05},0) {$+180^\circ$};")
out.append(r"\end{tikzpicture}")
open('../paper/figures/tikz/skymap.tex','w').write("\n".join(out))
print("ok", len(out))

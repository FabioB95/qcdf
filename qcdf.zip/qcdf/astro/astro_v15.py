"""Council checks on the sky campaigns (main DR3->DR4, replication DR2->DR3)."""
import json, math, numpy as np, healpy as hp
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from scipy.special import logit
from scipy.stats import binom
import astro_full as AF

PSR = ('psr', 'msp'); AGN = ('bll', 'fsrq', 'bcu')

def fit(X, y):
    ok = np.isfinite(X).all(1); sc = StandardScaler().fit(X[ok]); M = LogisticRegression(C=0.3, max_iter=2000).fit(sc.transform(X[ok]), y[ok])
    def pred(Z):
        okz = np.isfinite(Z).all(1); P = np.full(len(Z), y[ok].mean()); P[okz] = M.predict_proba(sc.transform(Z[okz]))[:, 1]; return P
    return M, pred

def rank_plan(S, score, K):
    Z = []
    for s in np.argsort(-score):
        if not len(S.rows[s]): continue
        a = int(S.rows[s][np.argmax(S.vals[s])])
        if a not in Z: Z.append(a)
        if len(Z) == K: break
    return Z

def covered(S, Z):
    Zs = np.zeros(S.n, bool); Zs[Z] = True
    return np.array([bool(len(r)) and bool(Zs[r].any()) for r in S.rows])

def campaign(TR, TE, rng):
    d2, n2, X2, y2 = AF.transition(*TR); d3, n3, X3, y3 = AF.transition(*TE); y = y3.astype(bool)
    M, pred = fit(X2, y2); P3 = pred(X3)
    out = dict(coef=dict(zip(AF.FEAT, M.coef_[0].round(3).tolist())))
    rb = np.random.default_rng(5); boots = []
    for _ in range(500):
        i = rb.integers(len(X2), size=len(X2)); Mb, _ = fit(X2[i], y2[i]); boots.append(Mb.coef_[0])
    out['coef_ci'] = {f: np.percentile(np.array(boots)[:, k], [2.5, 97.5]).round(3).tolist() for k, f in enumerate(AF.FEAT)}
    beta = np.nan_to_num(d3['LP_beta'].astype(float), nan=0.0)
    scores = dict(model=P3, curv=X3[:, 2], signif=X3[:, 6], lp_beta=beta)
    pos, neg = np.where(y)[0], np.where(~y)[0]
    out['auc'] = {k: float(roc_auc_score(y, v)) for k, v in scores.items()}
    dif = {k: [] for k in ('curv', 'signif', 'lp_beta')}; oes, sls = [], []
    lp = logit(np.clip(P3, 1e-6, 1 - 1e-6))
    for _ in range(2000):
        i = np.r_[rb.choice(pos, len(pos)), rb.choice(neg, len(neg))]
        am = roc_auc_score(y[i], P3[i])
        for k in dif: dif[k].append(am - roc_auc_score(y[i], scores[k][i]))
        j = rb.integers(len(y), size=len(y)); oes.append(y[j].sum() / P3[j].sum())
        sls.append(LogisticRegression(C=1e6).fit(lp[i][:, None], y[i]).coef_[0, 0])
    out['auc_diff_ci'] = {k: np.percentile(v, [2.5, 97.5]).round(3).tolist() for k, v in dif.items()}
    out['oe'] = [float(y.sum() / P3.sum()), *np.percentile(oes, [2.5, 97.5]).tolist()]
    out['slope'] = [float(LogisticRegression(C=1e6).fit(lp[:, None], y).coef_[0, 0]), *np.percentile(sls, [2.5, 97.5]).tolist()]
    _, nb, cb = AF.load(TE[1]); mb = dict(zip(nb, cb)); cls = np.array([mb.get(n, '') for n in n3])
    ispsr = y & np.isin(cls, PSR); out['n_pos'] = int(y.sum()); out['n_psr'] = int(ispsr.sum())
    dec = d3['DEJ2000'].astype(float); hi = dec > AF.DEC_MAX
    out['dec'] = dict(targets_above=int(hi.sum()), n_targets=int(len(y)), pos_above=int((y & hi).sum()),
                      p_zero=float(binom.pmf(0, int(y.sum()), hi.mean())))
    _, n_, c_ = AF.load(TE[0]); dA = AF.load(TE[0])[0]
    lab = np.isin(c_, PSR) | np.isin(c_, AGN); XA = AF.features(dA[lab]); yA = np.isin(c_[lab], PSR).astype(int)
    _, predC = fit(XA, yA); PC = predC(X3)
    out['auc']['classifier'] = float(roc_auc_score(y, PC)); out['auc_classifier_psr'] = float(roc_auc_score(ispsr, PC))
    out['auc_model_psr'] = float(roc_auc_score(ispsr, P3))
    _, pred4 = fit(X3, y3.astype(int)); P4 = pred4(X3)
    S = AF.Sky(d3, P3, rng)
    fore = dict(model=P3, classifier=PC * P3.mean() / PC.mean(), curvature=None, retrospective=P4)
    xev = {}
    for K in (50, 200):
        for fk, Pf in fore.items():
            if Pf is None:
                Zq = None; Zr = rank_plan(S, X3[:, 2], K)
            else:
                Sf = AF.Sky.__new__(AF.Sky); Sf.__dict__.update(S.__dict__); Sf.P = Pf
                Sf.h = np.zeros(S.n); J = {}
                for Ps, r, v in zip(Pf, S.rows, S.vals):
                    for a, va in zip(r, v): Sf.h[a] -= Ps * va
                    for x in range(len(r)):
                        for z in range(x + 1, len(r)):
                            a, b = sorted((int(r[x]), int(r[z]))); J[(a, b)] = J.get((a, b), 0.0) + Ps * v[x] * v[z]
                Sf.J = J; Zq, _ = Sf.milp(K); Zr = rank_plan(S, Pf, K)
            for rk, Z in (('QCDF', Zq), ('rank', Zr)):
                if Z is None: continue
                c = covered(S, Z); xev[f'{fk}|{rk}|{K}'] = dict(pos=int((c & y).sum()), psr=int((c & ispsr).sum()))
        rr = np.random.default_rng(K); rd = [covered(S, list(rr.choice(S.n, K, replace=False))) for _ in range(300)]
        xev[f'random|{K}'] = dict(pos=float(np.mean([(c & y).sum() for c in rd])), psr=float(np.mean([(c & ispsr).sum() for c in rd])))
        print(K, {k: v for k, v in xev.items() if k.endswith(f'|{K}')}, flush=True)
    out['xev'] = xev
    vis = dec < AF.DEC_MAX; idx = np.where(vis)[0]
    ra = np.radians(d3['RAJ2000'].astype(float)); de = np.radians(dec); a95 = d3['Conf_95_SemiMajor'].astype(float)
    vec = hp.ang2vec(np.pi / 2 - de, ra); tile = {}
    for s in idx:
        cand = idx[np.degrees(np.arccos(np.clip(vec[idx] @ vec[s], -1, 1))) <= a95[s]]
        tile[int(s)] = [int(j) for j in cand]
    npairs = sum(len(v) - 1 for v in tile.values()) // 2
    def tcov(Z):
        c = np.zeros(len(y), bool)
        for s in Z: c[tile[s]] = True
        return c
    def tgreedy(P, K):
        Z, c = [], np.zeros(len(y), bool)
        for _ in range(K):
            g = {s: P[[j for j in tile[s] if not c[j]]].sum() for s in tile if s not in Z}
            b = max(g, key=g.get); Z.append(b); c[tile[b]] = True
        return Z
    tt = {}
    for K in (50, 200):
        plans = dict(QCDF=tgreedy(P3, K), rank_model=[int(s) for s in idx[np.argsort(-P3[idx])][:K]],
                     curvature=[int(s) for s in idx[np.argsort(-X3[idx, 2])][:K]], brightest=[int(s) for s in idx[np.argsort(-np.nan_to_num(X3[idx, 0], nan=-20))][:K]],
                     classifier=[int(s) for s in idx[np.argsort(-PC[idx])][:K]])
        for k, Z in plans.items():
            c = tcov(Z); tt[f'{k}|{K}'] = dict(pos=int((c & y).sum()), psr=int((c & ispsr).sum()))
        rr = np.random.default_rng(K); rd = [tcov(list(rr.choice(idx, K, replace=False))) for _ in range(1000)]
        tt[f'random|{K}'] = dict(pos=float(np.mean([(c & y).sum() for c in rd])), pos_sd=float(np.std([(c & y).sum() for c in rd])),
                                psr=float(np.mean([(c & ispsr).sum() for c in rd])))
        tt[f'same_QCDF_rank|{K}'] = len(set(plans['QCDF']) & set(plans['rank_model']))
    out['tiling'] = dict(n_cand=int(len(idx)), overlapping_pairs=int(npairs), res=tt)
    print('tiling', out['tiling'], flush=True)
    return out

if __name__ == '__main__':
    rng = np.random.default_rng(7)
    o = dict(main=campaign(['gll_psc_v27.fit', 'gll_psc_v31.fit'], ['gll_psc_v31.fit', 'gll_psc_v35.fit'], rng),
             rep=campaign(['gll_psc_v22.fit', 'gll_psc_v27.fit'], ['gll_psc_v27.fit', 'gll_psc_v31.fit'], rng))
    json.dump(o, open('astro_v15.json', 'w'), indent=1); print('done')

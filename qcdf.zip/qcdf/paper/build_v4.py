"""Assemble QCDF v4 (restructured manuscript) reusing verified blocks of v3."""
import re
S = open('QCDF_main.tex').read()

def grab(start, end, s=S, after=0):
    a = s.index(start, after)
    b = s.index(end, a) + len(end)
    return s[a:b]

pre = S[:S.index(r'\begin{document}')]
pre = pre[pre.index(r'\documentclass'):]
pre = re.sub(r'\\title\{.*?\n\}\n', '', pre, flags=re.S)
pre = pre.replace(r"pdftitle   = {QCDF: A Quantum-Mechanical Framework for Spatial Decision-Making}",
                  r"pdftitle   = {Constraint-preserving QAOA for spatial decision-making}")
pre = re.sub(r'\\author\{.*?\\date\{\}\n', '', pre, flags=re.S)

notation = grab(r'\begin{longtable}', r'\end{longtable}')
lemma = grab(r'\begin{lemma}[Tunneling is projected out', r'\end{proof}')
tfim = grab(r'\begin{proposition}[QCDF is a non-uniform TFIM]', r'\end{proof}')
mrf = grab(r'\begin{proposition}[Markov random field of the effective cost]', r'\end{remark}')
mech1 = grab(r'\begin{proposition}[Exact feasibility of the Dicke ansatz]', r'\end{remark}')
mech2 = S[S.index(r'For constraints without a preserving ansatz'):S.index(r'\end{remark}', S.index(r'\label{rem:budget}')) + len(r'\end{remark}')]
astro_eq = grab(r'\begin{align}' + '\n' + r'  \vi &= \mathrm{minmax}_{\log}', r'\end{align}')
pilot_tab = grab(r'\begin{table}[t]' + '\n' + r'\centering' + '\n' + r'\caption{Pilot instance', r'\end{table}')
dixie_map_tab = S[S.rindex(r'\begin{table}', 0, S.index(r'\label{tab:dixie_mapping}')):S.index(r'\end{table}', S.index(r'\label{tab:dixie_mapping}')) + 11]
dixie_pil_tab = S[S.rindex(r'\begin{table}', 0, S.index(r'\label{tab:dixie_pilot}')):S.index(r'\end{table}', S.index(r'\label{tab:dixie_pilot}')) + 11]
domain = grab(r'\begin{proposition}[Domain independence, structural]', r'\end{remark}')
tunapp = grab(r'\begin{proposition}[Uncertainty-weighted tunneling allocation]', r'\end{remark}', after=S.index(r'\appendix'))

body = open('v4_body_filled.tex').read()
for k, v in dict(NOTATION=notation, LEMMA=lemma, TFIM=tfim, MRF=mrf, MECH1=mech1, MECH2=mech2,
                 ASTROEQ=astro_eq, PILOTTAB=pilot_tab, DIXIEMAPTAB=dixie_map_tab,
                 DIXIEPILTAB=dixie_pil_tab, DOMAIN=domain, TUNAPP=tunapp).items():
    body = body.replace('%%' + k + '%%', v)
assert '%%' not in body.replace('%%%', ''), [m for m in re.findall(r'%%[A-Z]+%%', body)]
open('QCDF_v4.tex', 'w').write(pre + body)
print('ok', len(pre + body))

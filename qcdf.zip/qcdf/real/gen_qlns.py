"""Thinning law against real QAOA sub-solvers: tokens, table and the extra points of the thinning figure. Inputs: lnsq_qaoa_fire.json, lnsq_qaoa_astro.json (QAOA arms) and lnsq.json, ../astro/lnsq_astro.json (exact and uniform arms)."""
import json, math, numpy as np
from scipy.stats import binom
EPS = 0.001
ref = {}
for r in json.load(open('lnsq.json')) + json.load(open('../astro/lnsq_astro.json')):
    ref[(r.get('domain', 'fire'), r.get('T0', ''), r['K'], r['w'], r['S'])] = r
import os
_SF = os.environ.get('QL_SUFFIX', '')
Q = json.load(open(f'lnsq_qaoa_fire{_SF}.json')) + json.load(open(f'lnsq_qaoa_astro{_SF}.json'))
def thin(tr, B, q): n = np.arange(B + 1); return float((binom.pmf(n, B, q) * tr).sum())
rows, pts = [], []
for key in sorted({(x['domain'], x['T0'], x['K'], x['w'], x['S']) for x in Q}):
    r = ref[key]; A = r['arms']; B = len(A['exact'][0]['gap'])
    g = np.mean([x['gap'] for x in A['exact']], 0); tr = np.r_[r['gap0'], g]; ex = g[-1]
    uni = float(np.mean([x['gap'][-1] for x in A['uniform']]) - ex)
    lo, hi = 1e-4, 1.0
    for _ in range(40):
        m = (lo + hi) / 2
        if thin(tr, B, m) - ex <= EPS: hi = m
        else: lo = m
    for mode in ('E', 'B'):
        X = [x for x in Q if (x['domain'], x['T0'], x['K'], x['w'], x['S']) == key and x['mode'] == mode]
        if not X: continue
        q = float(np.mean([np.mean(x['q']) for x in X])); pi = float(np.median(np.concatenate([x['pi'] for x in X])))
        qi = float(np.mean(np.concatenate([np.array(x['q'])[np.array(x['imp'], bool)] for x in X]))) if all('imp' in x for x in X) else q
        fimp = float(np.mean(np.concatenate([x['imp'] for x in X]))) if all('imp' in x for x in X) else float('nan')
        obs = float(np.mean([x['gap'][-1] for x in X]) - ex); pred = thin(tr, B, q) - ex; predi = thin(tr, B, qi) - ex
        rows.append(dict(dom=key[0], T0=key[1], K=key[2], w=key[3], S=key[4], mode=mode, n=len(X), q=q, qi=qi, fimp=fimp, pi=pi, obs=obs, pred=pred, predi=predi, uni=uni, qstar=hi))
        pts.append((key[0], mode, predi, obs))
ok = [x for x in rows if x['obs'] <= x['pred'] + EPS]; oki = [x for x in rows if x['obs'] <= x['predi'] + EPS]
above = [x for x in rows if x['q'] >= x['qstar']]; abovei = [x for x in rows if x['qi'] >= x['qstar']]
f2 = lambda v: f"{100*v:.2f}"
tok = dict(XQL_ncfg=str(len({(x['dom'], x['T0'], x['K'], x['w'], x['S']) for x in rows})), XQL_nrows=str(len(rows)), XQL_bound=str(len(ok)),
           XQL_qE=f"{min(x['q'] for x in rows if x['mode']=='E'):.2f}--{max(x['q'] for x in rows if x['mode']=='E'):.2f}",
           XQL_qB=f"{min(x['q'] for x in rows if x['mode']=='B'):.2f}--{max(x['q'] for x in rows if x['mode']=='B'):.2f}",
           XQL_above=str(len(above)), XQL_fail=str(len(rows) - len(ok)), XQL_bound_i=str(len(oki)), XQL_above_i=str(len(abovei)),
           XQL_qiE=f"{min(x['qi'] for x in rows if x['mode']=='E'):.2f}--{max(x['qi'] for x in rows if x['mode']=='E'):.2f}",
           XQL_qiB=f"{min(x['qi'] for x in rows if x['mode']=='B'):.2f}--{max(x['qi'] for x in rows if x['mode']=='B'):.2f}",
           XQL_mae=f"{100*np.mean([abs(x['obs']-x['pred']) for x in rows]):.2f}", XQL_mae_i=f"{100*np.mean([abs(x['obs']-x['predi']) for x in rows]):.2f}",
           XQL_corr=f"{np.corrcoef([x['pred'] for x in rows], [x['obs'] for x in rows])[0,1]:.2f}", XQL_corr_i=f"{np.corrcoef([x['predi'] for x in rows], [x['obs'] for x in rows])[0,1]:.2f}",
           XQL_beatuni=str(sum(1 for x in rows if x['mode'] == 'E' and x['obs'] < x['uni'] - EPS)), XQL_nE_behind=str(sum(1 for x in rows if x['mode'] == 'E' and x['obs'] > x['uni'] + EPS)), XQL_nE=str(sum(1 for x in rows if x['mode'] == 'E')))
lab = {'E': 'energy, $p=2$', 'B': 'best case, $p=3$'}
body = '\n'.join(f"{'wildfire ' + x['T0'][5:] if x['dom']=='fire' else 'sky'} & {x['K']} & {x['w']} & {x['S']} & {lab[x['mode']]} & {x['pi']:.3f} & {x['q']:.2f} & {x['qi']:.2f} & {x['qstar']:.2f} & {f2(x['pred'])} & {f2(x['predi'])} & {f2(x['obs'])} & {f2(x['uni'])} \\\\" for x in rows)
tok['XQL_TABLE'] = r"""\begin{table}[!htbp]
\centering
\caption{Thinning law with real QAOA sub-solvers in the large-neighbourhood
search (500 iterations, four seeds). $\pi$: median probability of the window
optimum; $q=1-(1-\pi)^S$, mean over used iterations; $q_{\rm imp}$: mean over
the iterations whose window admits an improvement; $q^\ast$: threshold of
Lemma~\ref{prop:thin} ($\varepsilon=0.1\%$). Excess gap over the exact
search (\%): thinning prediction from $q$ and from $q_{\rm imp}$, observed, and
uniform sampling.}
\label{tab:qlns}
\scriptsize\setlength{\tabcolsep}{2.5pt}
\begin{tabular}{lrrrlrrrrrrrr}
\toprule
Hamiltonian & $K$ & $w$ & $S$ & sub-solver & $\pi$ & $q$ & $q_{\rm imp}$ & $q^\ast$ & pred.\ ($q$) & pred.\ ($q_{\rm imp}$) & observed & uniform \\
\midrule
""" + body + r"""
\bottomrule
\end{tabular}
\end{table}"""
json.dump(dict(rows=rows, pts=pts), open('qlns_summary.json', 'w'), indent=1)
json.dump({k: v for k, v in tok.items() if k != 'XQL_TABLE'}, open('qlns_tokens.json', 'w'), indent=1)
fn = '../paper/v4_body_filled.tex'; s = open(fn).read()
for k_, v in sorted(tok.items(), key=lambda kv: -len(kv[0])): s = s.replace('@@' + k_ + '@@', v)
open(fn, 'w').write(s)
print({k: v for k, v in tok.items() if k != 'XQL_TABLE'})
for x in rows: print(x['dom'], x['T0'], x['K'], x['w'], x['S'], x['mode'], round(x['q'], 3), round(x['qi'], 3), round(x['fimp'], 3), round(x['qstar'], 3), f2(x['pred']), f2(x['predi']), f2(x['obs']), f2(x['uni']))

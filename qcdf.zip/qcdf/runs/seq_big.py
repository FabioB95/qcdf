"""Sequential allocation at larger scale: N=20 cells, k=1 per step, T=4 (80 binary variables, 160,000 feasible plans). Same model and allocators as seq.py; shallow QAOA omitted (already shown not competitive at N=10); surrogate energies evaluated in chunks."""
import sys, json, time, math, numpy as np
sys.path.insert(0, '.')
import seq, anneal as A

def feats_chunk(X):
    return seq.features(X.astype(float))

def run(n, k, T, sd, RA=500, M_fit=6000, TA=40.0):
    rng = np.random.default_rng(1000 + sd)
    F = seq.Fire(n, rng, R=1000); F.UA = F.UA[:RA]
    P = seq.ProductDicke(n, k, T, F.edges)
    t0 = time.time()
    LA = np.empty(P.dim)
    for a in range(P.dim):
        LA[a] = F.loss(P.X[a].reshape(T, n), F.UA)[0]
    t_enum = time.time() - t0
    fit = rng.choice(P.dim, M_fit, replace=False)
    coef, *_ = np.linalg.lstsq(feats_chunk(P.X[fit]), LA[fit], rcond=None)
    Esur = np.concatenate([feats_chunk(P.X[i:i + 4000]) @ coef for i in range(0, P.dim, 4000)])
    r2 = 1 - np.var(LA - Esur) / np.var(LA)
    hold = np.setdiff1d(np.arange(P.dim), fit)
    r2_out = 1 - np.var(LA[hold] - Esur[hold]) / np.var(LA[hold])
    a_s, a_o = int(np.argmin(Esur)), int(np.argmin(LA))
    plans = dict(none=np.zeros((T, n)), static=seq.static_plan(F, T, k), myopic=seq.myopic_plan(F, T, k),
                 seq_surrogate=P.X[a_s].reshape(T, n), oracle=P.X[a_o].reshape(T, n))
    class _Sp: pass
    sp = _Sp(); sp.pairs = P.full_pairs; sp.dim = P.dim
    En = (Esur - Esur.mean()) / Esur.std()
    burning = np.zeros((RA, n), bool); burning[:, F.src] = True; ever = burning.copy(); u_t = []
    for t in range(T):
        new = (burning[:, :, None] & (F.UA[:, t] < F.q[None])).any(1) & ~ever; ever |= new; burning = new
        pt = burning.mean(0); u_t.append(np.sqrt(pt * (1 - pt)))
    u_t = np.array(u_t); u_t /= max(u_t.max(), 1e-9)
    ub = np.array([(u_t[t, F.edges[e][0]] + u_t[t, F.edges[e][1]]) / 2 + 0.05 for t, e in P.pair_te])
    pa = {}
    for name, taus in dict(seq_anneal_linear=np.full(len(ub), 1e9), seq_anneal_u=0.35 * ub / ub.mean()).items():
        pr = A.anneal(sp, En, taus, TA, dt=0.1)
        plans[name] = P.X[int(np.argmax(pr))].reshape(T, n); pa[name] = float(pr[a_s])
    loss = {name: F.loss(pl, F.UB)[0] for name, pl in plans.items()}
    return dict(n=n, k=k, T=T, seed=sd, dim=P.dim, nvars=n * T, r2=float(r2), r2_out=float(r2_out),
                t_enum=t_enum, p_opt_anneal=pa, loss=loss)

if __name__ == '__main__':
    n, s0, s1, out = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
    res = []
    for sd in range(s0, s1):
        t = time.time(); r = run(n, 1, 4, sd); res.append(r)
        b = r['loss']['none']
        print(f"N={n} seed={sd} dim={r['dim']} R2={r['r2']:.4f}/{r['r2_out']:.4f} "
              + " ".join(f"{a}={100*(b-r['loss'][a])/b:.1f}" for a in ['static', 'myopic', 'seq_anneal_linear', 'seq_anneal_u', 'seq_surrogate', 'oracle'])
              + f" [{time.time()-t:.0f}s]", flush=True)
        json.dump(res, open(out, 'w'))

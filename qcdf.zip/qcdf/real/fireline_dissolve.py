"""Physical length of the Dixie Fire line network: exact-duplicate removal (as in fireline.py), noded union of the segments, and the length implied by the union of buffers of half-width b around every line (b = 10, 25 m), which merges redrawn or partially overlapping copies of the same line."""
import json, pandas as pd, geopandas as gpd, shapely
d = gpd.read_file('../realdata/fireline/Data/FirelineEngagement.gdb', layer='Firelines_Engagement_17_24', where="IncidentName LIKE '%Dixie%' OR IncidentName LIKE '%DIXIE%'", bbox=(-121.8, 39.6, -120.4, 40.6))
d = d[d.Year.astype(str).str.startswith('2021')].copy()
d['wkb'] = d.geometry.apply(lambda g: g.wkb if g is not None else b'')
d = d.groupby('wkb').tail(1).to_crs(3310)
out = dict(km_dedup=float(d.length.sum() / 1000))
g = shapely.line_merge(shapely.unary_union(d.geometry.values)); out['km_noded_union'] = float(g.length / 1000)
for b in (10, 25):
    u = shapely.unary_union(d.geometry.buffer(b, cap_style='flat').values); out[f'km_buffer_{b}m'] = float(u.area / (2 * b) / 1000)
json.dump(out, open('fireline_dissolve.json', 'w'), indent=1); print(out)

"""Supplementary table and tokens for the resource grid (fs_grid*.json): units K x effectiveness eta on the decision-time Dixie domain."""
import json, glob, numpy as np
R = []
for f in sorted(glob.glob('fs_grid_*.json')): R += json.load(open(f))
SET = [((0.85, 'const'), '$0.85$ (main)'), ((0.5, 'const'), '$0.5$'), ((0.3, 'const'), '$0.3$'),
       ((0.85, 'weather'), 'weather'), ((0.85, 'cond'), 'wind, slope')]
KS = (10, 20, 40, 80)
def rows(key, K): return [r for r in R if (r['eta'], r['mode']) == key and r['K'] == K]
def ms(x): x = np.array(x); return x.mean(), x.std(ddof=1) / np.sqrt(len(x)) if len(x) > 1 else 0.0
tok = {}; lines = []
cm = np.mean([r['eta_mean'] for r in R if r['mode'] == 'cond']) if any(r['mode'] == 'cond' for r in R) else float('nan')
for key, lab in SET:
    lab = lab
    first = True
    for K in KS:
        rs = rows(key, K)
        if not rs: continue
        g = lambda m: [r['saved_pct'][m] for r in rs]
        q = ms(g('QCDF_MILP'))
        d = lambda m: ms(np.array(g('QCDF_MILP')) - np.array(g(m)))
        dJ, dE, dG = d('QCDF_h_only'), d('B4_value_at_risk'), d('CELF_greedy')
        simple = max(('B1_communities', 'B2_nearest_front', 'B3_wind_downstream'), key=lambda m: np.mean(g(m)))
        nw = sum(1 for r in rs if r['saved_pct']['QCDF_MILP'] < r['saved_pct']['B4_value_at_risk'] - 1e-9)
        short = dict(B1_communities='C', B2_nearest_front='F', B3_wind_downstream='W')[simple]
        lines.append(f"{lab if first else ''} & ${K}$ & ${q[0]:.1f}\\pm{q[1]:.1f}$ & ${dJ[0]:+.1f}\\pm{dJ[1]:.1f}$ & ${dE[0]:+.1f}\\pm{dE[1]:.1f}$ & ${nw}/{len(rs)}$ & ${dG[0]:+.1f}\\pm{dG[1]:.1f}$ & ${np.mean(g(simple)):.1f}$ ({short}) & ${np.mean(g('B6_random')):.1f}$ \\\\")
        first = False
        k = f"{key[0]}{key[1]}K{K}".replace('.', '')
        tok[f'GR_{k}_q'] = f'{q[0]:.1f}'; tok[f'GR_{k}_dJ'] = f'{dJ[0]:+.1f}'; tok[f'GR_{k}_dE'] = f'{dE[0]:+.1f}'; tok[f'GR_{k}_dG'] = f'{dG[0]:+.1f}'
        tok[f'GR_{k}_nw'] = f'{nw}/{len(rs)}'; tok[f'GR_{k}_n'] = len(rs)
    if not first: lines.append('\\addlinespace')
tok['GR_cond_mean'] = f'{cm:.2f}'
open('grid_table.tex', 'w').write('\n'.join(lines[:-1]) + '\n')
json.dump(tok, open('grid_tokens.json', 'w'), indent=1)
print('\n'.join(lines))

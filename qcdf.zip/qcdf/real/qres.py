"""Quantum resource estimate: amplification of constraint-preserving QAOA on real LNS windows of both Hamiltonians."""
import sys, json, math, time, itertools, numpy as np
from scipy.optimize import minimize
sys.path.insert(0, '../out')
from qcdf_scaling import DickeSpace, qaoa_state
from lnsq import zmat

import os
PMAX, NWIN, RESTARTS = int(os.environ.get("QR_PMAX", 10)), int(os.environ.get("QR_NWIN", 4)), 3
SIZES = [(w, k) for w in (12, 16, 20) for k in (2, 3, 4)]

def fast_sub(P, W, Z):
    Zs = set(Z); inW = set(W); ks = len(Zs & inW)
    if ks == 0 or ks > 6: return None
    loc = {c: a for a, c in enumerate(W)}; Zm = zmat(len(W), ks).astype(float)
    heff = P.h[W].astype(float).copy(); pairs = []
    for c in W:
        for j, v in P.Jn.get(c, ()):
            if j in inW:
                if loc[c] < loc[j]: pairs.append((loc[c], loc[j], v))
            elif j in Zs: heff[loc[c]] += v
    E = Zm @ heff
    for a, b, v in pairs: E = E + v * Zm[:, a] * Zm[:, b]
    cur = np.array([1.0 if c in Zs else 0.0 for c in W]); idx = {tuple(r): t for t, r in enumerate(Zm.astype(int))}
    return dict(ks=ks, E=E, Zm=Zm, cur=idx[tuple(cur.astype(int))], nJ=len(pairs), rest=[c for c in Z if c not in inW])

def collect(P, Z0, seeds=60, iters=200):
    import lnsq as LQ
    P.Jn = {}
    for (i, j), v in P.J.items():
        P.Jn.setdefault(i, []).append((j, v)); P.Jn.setdefault(j, []).append((i, v))
    got = {s: [] for s in SIZES}
    for seed in range(seeds):
        rng = np.random.default_rng(1000 + seed); Z = list(Z0)
        for it in range(iters):
            for w in (12, 16, 20):
                W = LQ.window(P, rng, Z, w)
                if len(W) != w: continue
                pr = fast_sub(P, W, Z)
                if pr is None or (w, pr['ks']) not in got or len(got[(w, pr['ks'])]) >= NWIN: continue
                o = np.sort(pr['E'])
                if o[1] - o[0] < 1e-6 * max(1.0, abs(o[0])): continue
                edges = [(a, b) for a, c in enumerate(W) for b, d in enumerate(W) if a < b and d in P.adj[c]]
                got[(w, pr['ks'])].append(dict(W=[int(c) for c in W], ks=pr['ks'], E=pr['E'].tolist(), edges=edges, nJ=pr['nJ'], seed=seed, it=it, cur=int(pr['cur'])))
            W = LQ.window(P, rng, Z, 16); pr = fast_sub(P, W, Z) if len(W) == 16 else None
            if pr is not None:
                o = int(np.argmin(pr['E']))
                if pr['E'][o] < pr['E'][pr['cur']] - 1e-9:
                    Z = pr['rest'] + [W[k] for k in np.where(pr['Zm'][o] == 1)[0]]
            if all(len(v) >= NWIN for v in got.values()): return got
    return got

def fwd_states(x, sp, E):
    p = len(x) // 2; psi = np.full(sp.dim, 1 / math.sqrt(sp.dim), dtype=complex)
    for g, b in zip(x[:p], x[p:]):
        psi = psi * np.exp(-1j * g * E); cb, sb = math.cos(b), math.sin(b)
        for a01, a10 in sp.pairs:
            x01, x10 = psi[a01].copy(), psi[a10].copy()
            psi[a01] = cb * x01 - 1j * sb * x10; psi[a10] = cb * x10 - 1j * sb * x01
    return psi

def value_grad(x, sp, E, obs):
    p = len(x) // 2; phi = fwd_states(x, sp, E); lam = obs(phi); f = float(np.real(np.vdot(phi, lam)))
    g = np.zeros(len(x))
    for l in range(p - 1, -1, -1):
        b = x[p + l]; cb, sb = math.cos(-b), math.sin(-b)
        for a01, a10 in reversed(sp.pairs):
            Hphi = np.zeros_like(phi); Hphi[a01] = phi[a10]; Hphi[a10] = phi[a01]
            g[p + l] += 2 * np.real(np.vdot(lam, -1j * Hphi))
            for v in (phi, lam):
                x01, x10 = v[a01].copy(), v[a10].copy()
                v[a01] = cb * x01 - 1j * sb * x10; v[a10] = cb * x10 - 1j * sb * x01
        g[l] = 2 * np.real(np.vdot(lam, -1j * E * phi))
        ph = np.exp(1j * x[l] * E); phi = phi * ph; lam = lam * ph
    return f, g

def popt_of(psi, opt):
    return float(np.sum(np.abs(psi[opt]) ** 2))

def run_window(win, rng):
    w, k = len(win['W']), win['ks']; sp = DickeSpace(w, k, win['edges'])
    E = np.array(win['E']); E = (E - E.mean()) / (E.std() + 1e-12)
    opt = np.where(E <= E.min() + 1e-9)[0]; dim = sp.dim; base = len(opt) / dim
    mask = np.zeros(sp.dim); mask[opt] = 1.0
    fE = lambda x: value_grad(x, sp, E, lambda v: E * v)
    def fP(x):
        pv, gv = value_grad(x, sp, E, lambda v: mask * v); pv = max(pv, 1e-300); return -math.log(pv), -gv / pv
    bnd = lambda p: [(0, 2 * np.pi)] * p + [(0, np.pi)] * p
    out = []; prevE = prevP = None
    for p in range(1, PMAX + 1):
        def interp(x):
            q = p - 1; xo = np.concatenate([[0.0], x, [0.0]])
            return np.array([((i - 1) / q) * xo[i - 1] + ((q - i + 1) / q) * xo[i] for i in range(1, p + 1)])
        pad = lambda x: np.concatenate([x[:p - 1], [0.0], x[p - 1:], [0.0]])
        starts = [np.concatenate([interp(prevE[:p - 1]), interp(prevE[p - 1:])]), pad(prevE)] if prevE is not None else []
        starts += [np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)]) for _ in range(RESTARTS)]
        bE = min((minimize(fE, x0, jac=True, method='L-BFGS-B', bounds=bnd(p), options={'maxiter': 300}) for x0 in starts), key=lambda r: r.fun)
        startsP = [bE.x] + ([np.concatenate([interp(prevP[:p - 1]), interp(prevP[p - 1:])]), pad(prevP)] if prevP is not None else [])
        bP = min((minimize(fP, x0, jac=True, method='L-BFGS-B', bounds=bnd(p), options={'maxiter': 300}) for x0 in startsP), key=lambda r: r.fun)
        prevE, prevP = bE.x, bP.x
        pE = popt_of(qaoa_state(bE.x, sp, E), opt); pP = math.exp(-bP.fun)
        out.append(dict(p=p, xE=bE.x.tolist(), xP=bP.x.tolist(), A_E=pE / base, A_P=pP / base, eE=float(bE.fun)))
    return dict(w=w, k=k, dim=dim, nopt=len(opt), nE=len(win['edges']), nJ=win['nJ'], layers=out)

def transfer(res, wins):
    for (w, k) in SIZES:
        idx = [i for i, r in enumerate(res) if (r['w'], r['k']) == (w, k)]
        for i in idx:
            r = res[i]; win = wins[i]; sp = DickeSpace(w, k, win['edges'])
            E = np.array(win['E']); E = (E - E.mean()) / (E.std() + 1e-12); opt = np.where(E <= E.min() + 1e-9)[0]; base = len(opt) / sp.dim
            for L in r['layers']:
                others = [np.array(res[j]['layers'][L['p'] - 1]['xE']) for j in idx if j != i]
                L['A_T'] = float(np.median([popt_of(qaoa_state(x, sp, E), opt) for x in others]) / base) if others else None
                if others:
                    xm = np.median(np.array(others), 0); L['A_Tmed'] = popt_of(qaoa_state(xm, sp, E), opt) / base

if __name__ == '__main__':
    dom, out = sys.argv[1], sys.argv[2]; t0 = time.time(); rng = np.random.default_rng(7)
    if dom == 'fire':
        import fullscale as FS
        P = FS.Problem(sys.argv[3]).build_qubo(); P.eset = set(P.elig.tolist())
        Z0 = list(P.elig[np.argsort(P.h[P.elig])[:20]])
    else:
        sys.path.insert(0, '../astro'); import pickle
        d = pickle.load(open(sys.argv[3], 'rb'))
        class Ham: pass
        P = Ham(); P.h, P.J, P.adj = d['h'], d['J'], d['adj']; P.elig = np.arange(len(P.h)); P.eset = set(range(len(P.h)))
        Z0 = list(np.argsort(P.h)[:50])
    got = collect(P, Z0); wins = [x for s in SIZES for x in got[s]]
    print(dom, {s: len(v) for s, v in got.items()}, f'[{time.time()-t0:.0f}s]', flush=True)
    res = []
    if os.path.exists(out):
        prev = json.load(open(out)); wins = prev['wins']; res = prev['res']
    for win in wins[len(res):]:
        r = run_window(win, rng); r['domain'] = dom; res.append(r)
        print(dom, r['w'], r['k'], r['dim'], [round(L['A_E'], 2) for L in r['layers']], [round(L['A_P'], 1) for L in r['layers']], f'[{time.time()-t0:.0f}s]', flush=True)
        json.dump(dict(res=res, wins=wins), open(out, 'w'))
    transfer(res, wins)
    json.dump(dict(res=res, wins=wins), open(out, 'w')); print('done', f'[{time.time()-t0:.0f}s]')

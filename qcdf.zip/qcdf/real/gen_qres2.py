"""Tokens and table of the second resource pass: mixer classes, improving-state target, depth exponents, threshold-oracle cost and the noise level measured on hardware."""
import json, math, numpy as np
tok = {}
R = []
for d in ('fire', 'astro'): R += json.load(open(f'qres2_{d}.json'))
P = len(R[0]['layers']); MIX = [('xyw', 'window-graph $XY$'), ('xyc', 'complete-graph $XY$'), ('grover', 'Grover mixer')]
med = lambda rs, key, p: float(np.median([r['layers'][p - 1][key] for r in rs if r['layers'][p - 1][key] is not None]))
rows = []
for m, lab in MIX:
    rs = [r for r in R if r['mixer'] == m]
    ai = [r['layers'][P - 1]['Pimp_E'] / (r['nimp'] / r['dim']) for r in rs if r['nimp'] > 0 and r['layers'][P - 1]['Pimp_E'] is not None]
    aa = [min(math.sin((2 * P + 1) * math.asin(math.sqrt(r['nimp'] / r['dim']))) ** 2, 1) / (r['nimp'] / r['dim']) for r in rs if r['nimp'] > 0]
    tok[f'XQ2_{m}_E'] = f"{med(rs, 'A_E', P):.1f}"; tok[f'XQ2_{m}_B'] = f"{med(rs, 'A_B', P):.1f}"; tok[f'XQ2_{m}_I'] = f"{np.median(ai):.1f}"
    rows.append(f"{lab} & {med(rs, 'A_E', 1):.1f} & {med(rs, 'A_E', P):.1f} & {med(rs, 'A_B', P):.1f} & {np.median(ai):.1f} & {np.median(aa):.1f} \\\\")
tok['XQ2_n'] = str(len({(r['domain'], r['i']) for r in R})); tok['XQ2_P'] = str(P)
tok['XQ2_dims'] = f"{min(r['dim'] for r in R)}--{max(r['dim'] for r in R)}"
tok['XQ2_nimp_med'] = f"{np.median([r['nimp'] / r['dim'] for r in R if r['nimp'] > 0]) * 100:.0f}"
Q = []
for d in ('fire', 'astro'): Q += json.load(open(f'qres_{d}.json'))['res']
al = []
for r in Q:
    ps = np.arange(3, len(r['layers']) + 1); A = np.array([r['layers'][p - 1]['A_P'] for p in ps])
    if (A > 0).all(): al.append(np.polyfit(np.log(ps), np.log(A), 1)[0])
tok['XQ2_alpha'] = f"{np.median(al):.2f}"; tok['XQ2_alpha_iqr'] = f"{np.percentile(al, 25):.2f}--{np.percentile(al, 75):.2f}"
w, k, b, nJ = 20, 4, 8, int(np.median([x['nJ'] for d in ('fire', 'astro') for x in json.load(open(f'qres_{d}.json'))['wins'] if len(x['W']) == 20]))
ndicke = 5 * w * k - 5 * k * k - 2 * w
oracle = 2 * (b * (2 * w + 8 * nJ) + b * (b - 1))
refl = 12 * (w + b)
tok.update(XQ2_cz_dicke=str(ndicke), XQ2_cz_oracle=f"{oracle:,}".replace(',', '{,}'), XQ2_cz_refl=str(refl),
           XQ2_cz_aa=f"{2 * ndicke + oracle + refl:,}".replace(',', '{,}'), XQ2_nJ=str(nJ), XQ2_b=str(b))
pobs, pid, base = 0.098, 0.7595, 1 / 64
Feff = (pobs - base) / (pid - base); eps = 1 - Feff ** (1 / 199)
tok.update(XQ2_Feff=f"{Feff:.2f}", XQ2_eps=f"{100 * eps:.1f}")
cz = json.load(open('qres_tokens.json'))
czl = float(cz['XQR_cz_layer'].replace('{,}', ''))
def Ash(Fid, A, dim, nq): return Fid * A + (1 - Fid) * dim / 2 ** nq
QB = [r for r in Q if r['w'] == 20 and r['k'] == 4]
best = {}
for e in (1e-3, eps):
    vals = []
    for p in range(1, len(QB[0]['layers']) + 1):
        Fp = (1 - e) ** (ndicke + p * czl * 2)
        vals.append(np.median([Ash(Fp, r['layers'][p - 1]['A_P'], r['dim'], 20) for r in QB]))
    best[e] = (int(np.argmax(vals)) + 1, float(max(vals)))
tok['XQ2_pbest3'] = str(best[1e-3][0]); tok['XQ2_Abest3'] = f"{best[1e-3][1]:.2f}"; tok['XQ2_Abest_hw'] = f"{best[eps][1]:.1e}".replace('e-0', '\\times10^{-').replace('e-', '\\times10^{-') + ('}' if 'e-' in f"{best[eps][1]:.1e}" else '')
tok['XQ2_TABLE'] = r"""\begin{table}[!htbp]
\centering
\caption{Mixer classes on """ + tok['XQ2_n'] + r""" real LNS windows of both Hamiltonians
($|\feasible_k(W)|=""" + tok['XQ2_dims'] + r"""$): median amplification over uniform
sampling of the window subspace. Energy: angles optimised for $\langle H\rangle$
at $p=1$ and $p=""" + str(P) + r"""$; best found: angles optimised for the probability of the
optimum (two random starts plus warm starts); improving: probability of drawing a
state better than the incumbent with energy-optimised angles at $p=""" + str(P) + r"""$, relative
to uniform sampling; AA: ideal amplitude amplification with a threshold oracle for
``better than the incumbent'' after $""" + str(P) + r"""$ iterations.}
\label{tab:mixers}
\footnotesize
\begin{tabular}{lrrrrr}
\toprule
Mixer & energy, $p=1$ & energy, $p=""" + str(P) + r"""$ & best found & improving & AA (threshold) \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}"""
json.dump({k_: v for k_, v in tok.items() if k_ != 'XQ2_TABLE'}, open('qres2_tokens.json', 'w'), indent=1)
fn = '../paper/v4_body_filled.tex'; s = open(fn).read()
for k_, v in sorted(tok.items(), key=lambda kv: -len(kv[0])): s = s.replace('@@' + k_ + '@@', v)
open(fn, 'w').write(s)
print({k_: v for k_, v in tok.items() if k_ != 'XQ2_TABLE'})

"""Tokens and tables for the referee checks of v14: fires as the unit (Dixie, Caldor, Monument), reachability of the spread model, plan stability, DINS coverage at K=5 and 20, forecast-versus-allocator cross-evaluation, greedy on the surrogate, and the sky checks of ../astro/astro_v14.json."""
import json, numpy as np, pandas as pd
tok = {}
f1 = lambda x: f"{x:.1f}"; sg = lambda x: f"{x:+.1f}"
FIRES = [('Dixie', 'fsP_act.json'), ('Caldor', 'fsC.json'), ('Monument', 'fsM.json')]
rows = []
for lab, fn in FIRES:
    R = json.load(open(fn)); v = lambda m: np.array([r['K']['10']['eval'][m]['saved_pct'] for r in R])
    q = v('QCDF_MILP'); cells = [f"{len(R)}", f1(q.mean())]
    for m in ('QCDF_h_only', 'B4_value_at_risk', 'CELF_greedy'):
        d = q - v(m); pos = int((d > 0.05).sum()); cells.append(f"${sg(d.mean())}$ ({pos}/{len(R)})")
    rows.append(f"{lab} & " + " & ".join(cells) + " \\\\")
tok['XF4_FIRETAB'] = r"""\begin{table}[!htbp]
\centering
\caption{The three fires as the unit of inference: the pre-specified primary
contrasts at $K=10$ (prospective model). QCDF: simulated exposure avoided (\%,
mean over dates); then QCDF minus each reference in points, with the number of
dates on which QCDF is ahead. Dixie: active phase; Caldor and Monument: all
dates.}
\label{tab:fires}
\footnotesize
\begin{tabular}{lrrccc}
\toprule
Fire & dates & QCDF & minus fields only & minus value at risk & minus simulator greedy \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}"""
C = pd.read_csv('calib_check_v12_cells.csv.gz'); A = C[(C.model == 'prospective') & (C.T0 <= '2021-08-05')]; b = A[A.y == 1]
tok['XF4_unreach'] = f"{100*(b.p < 0.01).mean():.0f}"; tok['XF4_unreachH'] = f"{100*b.H[b.p < 0.01].sum()/b.H.sum():.0f}"
R = json.load(open('fsP_act.json'))
for K in ('10', '20'):
    P = [set(r['K'][K]['eval']['QCDF_MILP']['plan']) for r in R]; ov = [len(P[i] & P[i + 1]) for i in range(len(P) - 1)]
    tok[f'XF4_stab{K}'] = f1(np.mean(ov))
    if K == '10': tok['XF4_stab10r'] = f"{min(ov)}--{max(ov)}"
import geopandas as gpd
G = pd.read_csv('dins_cells.csv'); dins = dict(zip(G.h3, G.dins_res_destroyed))
GR = gpd.read_file('grid_r7.gpkg'); GR['ign_date'] = pd.to_datetime(GR['ign_date']); ign = dict(zip(GR.h3, GR.ign_date))
def dcov(rs, K, m):
    num = den = 0
    for r in rs:
        T0 = pd.Timestamp(r['T0']); hit = lambda c: (c in ign) and pd.notna(ign[c]) and T0 < ign[c] <= T0 + pd.Timedelta(days=10)
        num += sum(dins.get(c, 0) for c in r['K'][K]['eval'][m]['plan'] if hit(c)); den += sum(v for c, v in dins.items() if hit(c))
    return 100 * num / max(den, 1)
for K in ('5', '20'):
    tok[f'XF4_dins{K}'] = f"{dcov(R, K, 'QCDF_MILP'):.0f}"; tok[f'XF4_dinsc{K}'] = f"{dcov(R, K, 'B1_communities'):.0f}"
X = {m: {r['T0']: r for r in json.load(open(f'xev_{m}.json'))} for m in ('prospective', 'rolling', 'oracle')}
SRC = ['prospective', 'rolling', 'oracle']; METH = ['QCDF_MILP', 'QCDF_h_only', 'B4_value_at_risk', 'CELF_greedy']
xf, xr, xd = [], [], []
for ev, byd in X.items():
    for d, r in byd.items():
        for m in METH:
            vals = [r[f'{s}|{m}'] for s in SRC if f'{s}|{m}' in r]
            if len(vals) == 3: xf.append(max(vals) - min(vals))
        for s in SRC:
            vals = [r[f'{s}|{m}'] for m in METH if f'{s}|{m}' in r]
            if len(vals) == 4: xr.append(max(vals) - min(vals))
        own = r.get(f'{ev}|QCDF_MILP'); oth = [r[f'{s}|QCDF_MILP'] for s in SRC if s != ev and f'{s}|QCDF_MILP' in r]
        if own is not None and oth: xd.append(own - np.mean(oth))
tok.update(XF4_xf=f1(np.mean(xf)), XF4_xr=f1(np.mean(xr)), XF4_xdiag=sg(np.mean(xd)), XF4_xratio=f"{np.mean(xf)/max(np.mean(xr),1e-9):.1f}")
lab = {'prospective': 'prospective', 'rolling': 'rolling', 'oracle': 'retrospective'}; mlab = {'QCDF_MILP': 'QCDF', 'QCDF_h_only': 'fields only', 'B4_value_at_risk': 'value at risk', 'CELF_greedy': 'simulator greedy'}
trows = []
for s in SRC:
    for m in METH:
        cells = [f1(np.mean([X[ev][d][f'{s}|{m}'] for d in X[ev] if f'{s}|{m}' in X[ev][d]])) for ev in SRC]
        trows.append(f"{lab[s]} & {mlab[m]} & " + " & ".join(cells) + " \\\\")
tok['XF4_XEVALTAB'] = r"""\begin{table}[!htbp]
\centering
\caption{Forecast versus allocator: simulated exposure avoided (\%, $K=10$,
mean over the 10 active-phase dates of Dixie) by plans built under one spread
model with one rule (rows), evaluated under each model (columns) on the same
held-out realisations.}
\label{tab:xeval}
\footnotesize
\begin{tabular}{llccc}
\toprule
Plan built under & rule & \multicolumn{3}{c}{evaluated under} \\
 & & prospective & rolling & retrospective \\
\midrule
""" + "\n".join(trows) + r"""
\bottomrule
\end{tabular}
\end{table}"""
SG = json.load(open('sgreedy.json'))
tok['XF4_sgE'] = f"{100*np.mean([(x['E_sgreedy'] - x['E_milp']) / abs(x['E_milp']) for x in SG]):.2f}"
tok['XF4_sgv'] = sg(np.mean([x['v_sgreedy'] - x['v_milp'] for x in SG])); tok['XF4_mono'] = f"{100*np.mean([x['monotone_frac'] for x in SG]):.0f}"
AS = json.load(open('../astro/astro_v14.json'))
def classes(c):
    psr = sum(v for k, v in c.items() if k in ('psr', 'msp')); blz = sum(v for k, v in c.items() if k in ('bcu', 'bll', 'fsrq'))
    rest = sum(c.values()) - psr - blz
    return f"{psr} pulsars, {blz} blazars and {rest} of other classes"
M, Rp = AS['main'], AS['rep']
tok.update(XA4_classes=classes(M['classes']), XA4_missing=str(M['missing_in_later']), XA4_ntgt=f"{M['n_targets']:,}".replace(',', '{,}'))
K = M['K']['200']
tok.update(XA4_q10=str(K['QCDF_MILP']['t0.1']), XA4_q50=str(K['QCDF_MILP']['t0.5']), XA4_c10=str(K['most_curved']['t0.1']), XA4_c50=str(K['most_curved']['t0.5']),
           XA4_b10=str(K['brightest']['t0.1']), XA4_b50=str(K['brightest']['t0.5']))
ci = lambda v: f"[{v[0]:+.0f},\\,{v[1]:+.0f}]"
tok.update(XA4_dc=f"{K['QCDF_MILP']['t0.01'] - K['most_curved']['t0.01']:+d}", XA4_dc_ci=ci(K['most_curved']['diff_ci']),
           XA4_db=f"{K['QCDF_MILP']['t0.01'] - K['brightest']['t0.01']:+d}", XA4_db_ci=ci(K['brightest']['diff_ci']))
KR = Rp['K']['200']
tok.update(XA4R_dc=f"{KR['QCDF_MILP']['t0.01'] - KR['most_curved']['t0.01']:+d}", XA4R_dc_ci=ci(KR['most_curved']['diff_ci']),
           XA4R_db=f"{KR['QCDF_MILP']['t0.01'] - KR['brightest']['t0.01']:+d}", XA4R_db_ci=ci(KR['brightest']['diff_ci']))
tok.update(XA4_auc=f"{M['auc'][0]:.2f}", XA4_auc_ci=f"95\\% interval {M['auc'][1]:.2f}--{M['auc'][2]:.2f}", XA4_auccurv=f"{M['auc_curv']:.2f}",
           XA4_rand=f"{K['random']['t0_01_mean']:.1f}", XA4_gap=f"{max(100*(1 - M['K'][k]['bound']['F_greedy']/M['K'][k]['bound']['upper']) for k in ('20', '50', '200')):.0f}")
json.dump({k: v for k, v in tok.items() if not k.endswith('TAB')}, open('v14_tokens.json', 'w'), indent=1)
fn = '../paper/v4_body_filled.tex'; s = open(fn).read()
for k_, v in sorted(tok.items(), key=lambda kv: -len(kv[0])): s = s.replace('@@' + k_ + '@@', v)
open(fn, 'w').write(s)
print({k: v for k, v in tok.items() if not k.endswith('TAB')})

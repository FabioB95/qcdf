"""Calendar-consistent open-loop reference for the forward study (fwd.py)."""
import sys, json, time, numpy as np
sys.argv_saved2 = list(sys.argv); sys.argv = ['x']
import fwd as F
sys.argv = sys.argv_saved2
from fastsim import _sim

R_PLAN, MINF = 300, 0.02

def losses(sched, R, stream):
    P = np.zeros((F.H_ALL, F.n))
    for c, d in sched: P[d:, c] = F.ETA
    L = np.zeros(R); fr = np.zeros(F.n, np.int64)
    _sim(F.src, F.dst, np.ascontiguousarray(F.Q[:F.H_ALL]), F.b_obs0.astype(np.uint8), F.value, P, 0.0, R, stream, L, fr)
    return L, fr / R

def build():
    sched = []; t0 = time.time()
    for k, d in enumerate(F.DOFF):
        base, fr = losses(sched, R_PLAN, 9000)
        used = {c for c, _ in sched}
        cand = [c for c in np.where((fr >= MINF) & (F.b_obs0 == 0))[0] if c not in used]
        gain = {c: base.mean() - losses(sched + [(int(c), d)], R_PLAN, 9000)[0].mean() for c in cand}
        pick = sorted(gain, key=lambda c: -gain[c])[:F.KNEW]
        sched += [(int(c), d) for c in pick]
        print('date', k, d, 'cand', len(cand), 'base', round(base.mean(), 1), 'gains', [round(gain[c], 1) for c in pick], f'[{time.time()-t0:.0f}s]', flush=True)
    return sched

def evaluate(sched, rs, stream_out=777):
    out = []
    for r in rs:
        b = F.b_obs0.copy(); units = []; tprev = 0
        for k, t in enumerate(F.DOFF):
            prot = np.zeros(F.n); prot[units] = F.ETA
            F.segment(b, F.Q, prot, tprev, t, r, stream_out, F.src, F.dst); tprev = t
            units = [c for c, _ in sched[:F.KNEW * (k + 1)]]
        prot = np.zeros(F.n); prot[units] = F.ETA
        F.segment(b, F.Q, prot, tprev, F.H_ALL, r, stream_out, F.src, F.dst)
        out.append(dict(r=r, OL_seq=float(((b == 1) & (F.b_obs0 == 0)) @ F.value)))
    return out

if __name__ == '__main__':
    sched = build()
    runs = []
    for f in ('fwd_a.json', 'fwd_b.json'): runs += json.load(open(f))['runs']
    ev = evaluate(sched, [x['r'] for x in runs])
    json.dump(dict(sched=sched, runs=ev), open('fwd_ol.json', 'w'))
    print('done')

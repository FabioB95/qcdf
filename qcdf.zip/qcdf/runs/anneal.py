"""Uncertainty-scheduled annealing inside the feasible subspace (Strategy 3, done correctly)."""
import numpy as np, math, json, sys
sys.path.insert(0, '.')
from tts import Space, instance
sys.path.insert(0, '../out')
from qcdf_scaling import hex_patch, W_C, W_R, W_U, W_V

from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh
_gs = {}
def driver_ground(sp):
    if id(sp) not in _gs:
        r = np.concatenate([np.concatenate([a, b]) for a, b in sp.pairs])
        c = np.concatenate([np.concatenate([b, a]) for a, b in sp.pairs])
        H = coo_matrix((-np.ones(len(r)), (r, c)), shape=(sp.dim, sp.dim)).tocsr()
        w, v = eigsh(H, k=1, which='SA'); _gs[id(sp)] = v[:, 0].astype(complex)
    return _gs[id(sp)].copy()

def anneal(sp, E, taus, TA, dt=0.05):
    psi = driver_ground(sp); M = int(math.ceil(TA / dt)); dt = TA / M
    s_grid = (np.arange(M) + 0.5) / M
    integ = np.array([np.mean((1 - s_grid) * np.exp(-s_grid / t)) for t in taus])
    c = np.mean((1 - s_grid)) / integ.mean()
    for s in s_grid:
        psi *= np.exp(-1j * dt * s * E)
        for (a01, a10), tau in zip(sp.pairs, taus):
            th = -dt * (1 - s) * c * math.exp(-s / tau)
            cb, sb = math.cos(th), math.sin(th)
            x01, x10 = psi[a01], psi[a10]
            psi[a01] = cb * x01 - 1j * sb * x10; psi[a10] = cb * x10 - 1j * sb * x01
    return np.abs(psi) ** 2

if __name__ == '__main__':
    rng = np.random.default_rng(77); tau0 = 0.35; rows = []
    for n in (10, 12):
        ed = hex_patch(n); sp = Space(n, n // 2, ed)
        for inst in range(10):
            v, c_, r_, u = rng.random((4, n))
            u = rng.beta(0.6, 0.6, n)
            h = W_C * c_ + W_R * r_ + W_U * u - W_V * v
            E = sp.energies(h); En = (E - E.mean()) / E.std(); opt = np.isclose(E, E.min())
            ub = lambda uu: np.array([(uu[i] + uu[j]) / 2 + 0.05 for i, j in ed])
            U = ub(u); us = ub(rng.permutation(u))
            sched = dict(linear=np.full(len(ed), 1e9), uniform=np.full(len(ed), tau0), u_sched=tau0 * U / U.mean(),
                         inverse=tau0 * U.mean() / U, shuffled=tau0 * us / us.mean())
            for TA in (5, 20, 80):
                row = dict(N=n, inst=inst, TA=TA, P_unif=float(opt.mean()))
                for name, taus in sched.items():
                    pr = anneal(sp, En, taus, TA)
                    row['P_' + name] = float(pr[opt].sum())
                    row['r_' + name] = float((En.max() - pr @ En) / (En.max() - En.min()))
                rows.append(row)

            for L in (4, 10, 20, 40):
                pr = anneal(sp, En, np.full(len(ed), 1e9), TA=0.6 * L, dt=0.6)
                rows.append(dict(N=n, inst=inst, TA=-L, P_unif=float(opt.mean()), P_linear=float(pr[opt].sum()),
                                 r_linear=float((En.max() - pr @ En) / (En.max() - En.min()))))
            print(n, inst, {k: round(v, 4) for k, v in rows[-1].items() if k.startswith('P_')}, flush=True)
    json.dump(rows, open('anneal.json', 'w'))

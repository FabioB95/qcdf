"""Anticipation of the destroyed residences (DINS), counted once per residence: a residence destroyed in cell c on day t_c is anticipated by a rule if c was in the rule's plan (K units) on a decision date T0 with T0 + L <= t_c <= T0 + 10, for a lead time L of 1 or 2 days. Reported with and without the Greenville cell, which holds most destroyed residences."""
import json, sys, numpy as np, pandas as pd, geopandas as gpd
G = pd.read_csv('dins_cells.csv'); dins = {c: v for c, v in zip(G.h3, G.dins_res_destroyed) if v > 0}
GR = gpd.read_file('grid_r7.gpkg'); GR['ign_date'] = pd.to_datetime(GR['ign_date']); ign = dict(zip(GR.h3, GR.ign_date))
GV = max(dins, key=dins.get)
METH = ['B6_random', 'B1_communities', 'B2_nearest_front', 'B3_wind_downstream', 'B4_value_at_risk', 'QCDF_h_only', 'QCDF_SA', 'QCDF_MILP', 'CELF_greedy']
def run(fn, K='10'):
    R = sorted(json.load(open(fn)), key=lambda r: r['T0']); R = [r for r in R if r['T0'] <= '2021-08-05']
    d0, d1 = pd.Timestamp(R[0]['T0']), pd.Timestamp(R[-1]['T0'])
    out = {}
    for L in (1, 2):
        elig = {c: v for c, v in dins.items() if c in ign and pd.notna(ign[c]) and d0 + pd.Timedelta(days=L) <= ign[c] <= d1 + pd.Timedelta(days=10)}
        for m in METH:
            hit = set()
            for r in R:
                T0 = pd.Timestamp(r['T0'])
                for c in r['K'][K]['eval'][m]['plan']:
                    if c in elig and T0 + pd.Timedelta(days=L) <= ign[c] <= T0 + pd.Timedelta(days=10): hit.add(c)
            tot = sum(elig.values()); totx = tot - elig.get(GV, 0)
            n = sum(elig[c] for c in hit); nx = n - (elig[GV] if GV in hit else 0)
            out[f'{m}_L{L}'] = dict(n=int(n), tot=int(tot), share=n / tot, n_noGV=int(nx), tot_noGV=int(totx), share_noGV=nx / max(totx, 1), gv=GV in hit)
    return out
if __name__ == '__main__':
    res = {fn: run(fn) for fn in sys.argv[1:]}
    json.dump(dict(GV=GV, GV_res=int(dins[GV]), res=res), open('dins_v15.json', 'w'), indent=1)
    for fn, o in res.items():
        print(fn)
        for k, v in o.items(): print(' ', k, v['n'], '/', v['tot'], round(100 * v['share']), '% | noGV', v['n_noGV'], '/', v['tot_noGV'], round(100 * v['share_noGV']), '% GV', v['gv'])

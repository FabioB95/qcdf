"""Tokens for v13: calendar-consistent open-loop reference (fwd_ol.json) and spatially merged fireline length (fireline_dissolve.json)."""
import json, numpy as np
R = []
for f in ('fwd_a.json', 'fwd_b.json'): R += json.load(open(f))['runs']
O = {x['r']: x['OL_seq'] for x in json.load(open('fwd_ol.json'))['runs']}
none = np.array([r['none'] for r in R]); cl = np.array([r['CL_QCDF'] for r in R]); ol = np.array([O[r['r']] for r in R])
pct = lambda x: 100 * (none.sum() - x.sum()) / none.sum()
rng = np.random.default_rng(3); n = len(R); idx = rng.integers(n, size=(10000, n))
d = 100 * (ol[idx].sum(1) - cl[idx].sum(1)) / none[idx].sum(1); lo, hi = np.percentile(d, [2.5, 97.5])
tok = dict(XW_OL_seq=f"{pct(ol):.1f}", XW_gain_seq=f"{pct(cl) - pct(ol):.1f}", XW_ci_seq=f"[{lo:+.1f},\\,{hi:+.1f}]")
D = json.load(open('fireline_dissolve.json'))
fmt = lambda x: f"{x:,.0f}".replace(',', '{,}')
r100 = lambda x: f"{round(x, -2):,.0f}".replace(',', '{,}')
tok.update(XR_fl_km_noded=fmt(D['km_noded_union']), XR_fl_km_u10=r100(D['km_buffer_10m']), XR_fl_km_u25=r100(D['km_buffer_25m']))
OP = json.load(open('ops.json'))
tok.update(XP_road_q=f"{np.mean([o['road']['QCDF_MILP'] for o in OP]):.1f}", XP_road_v=f"{np.mean([o['road']['B4_value_at_risk'] for o in OP]):.1f}")
json.dump(tok, open('v13_tokens.json', 'w'), indent=1)
fn = '../paper/v4_body_filled.tex'; s = open(fn).read()
for k_, v in sorted(tok.items(), key=lambda kv: -len(kv[0])): s = s.replace('@@' + k_ + '@@', v)
open(fn, 'w').write(s); print(tok)

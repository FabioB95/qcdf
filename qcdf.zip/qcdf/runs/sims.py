"""Simulations of the pilot and of random instances: probability of the optimum, feasibility and uniform baselines."""
import numpy as np, json, h3, sys
from scipy.optimize import minimize
from pilot import h as h_astro, ED as ED_astro
sys.path.insert(0,'../out')
from qcdf_scaling import DickeSpace, qaoa_state, qaoa_energy, optimise_qaoa
def best_of(sp,E,p,R,seed):
    rng=np.random.default_rng(seed);best=None
    for t in range(R):
        x0=np.concatenate([rng.uniform(0,2*np.pi,p),rng.uniform(0,np.pi,p)])
        r=minimize(qaoa_energy,x0,args=(sp,E),method='L-BFGS-B',bounds=[(0,2*np.pi)]*p+[(0,np.pi)]*p)
        if best is None or r.fun<best.fun: best=r
    pr=np.abs(qaoa_state(best.x,sp,E))**2
    return best, pr
out={}

sp=DickeSpace(6,3,ED_astro); rows=[]
fieldE=sp.Z@h_astro
for J in np.round(np.arange(0,0.61,0.025),3):
    E=sp.energies(h_astro,J); o=np.argmin(E)
    b,pr=best_of(sp,E,4,100,1)
    rows.append(dict(J=float(J),Estar=float(E.min()),Emean=float(b.fun),Popt=float(pr[o]),
                     opt=''.join(map(str,sp.Z[o]))))
    print(rows[-1],flush=True)
out['jscan']=rows

E=sp.energies(h_astro,0.3);o=np.argmin(E);rows=[]
for p in range(1,7):
    b,pr=best_of(sp,E,p,100,2)
    rows.append(dict(p=p,Emean=float(b.fun),Popt=float(pr[o])));print(rows[-1],flush=True)
out['pscan']=rows

rng=np.random.default_rng(3);mins=[]
for t in range(300):
    x0=np.concatenate([rng.uniform(0,2*np.pi,4),rng.uniform(0,np.pi,4)])
    r=minimize(qaoa_energy,x0,args=(sp,E),method='L-BFGS-B',bounds=[(0,2*np.pi)]*4+[(0,np.pi)]*4)
    mins.append((float(r.fun),float(np.abs(qaoa_state(r.x,sp,E))[o]**2)))
out['minima']=mins

cells=[(39.70,-121.76,1.000,.423,.038,.529),(39.79,-121.59,.617,.483,.147,.092),(39.55,-121.75,.660,.534,.037,.168),
       (39.64,-121.58,.535,.532,.115,.194),(39.49,-121.57,.409,.609,.060,.512),(39.57,-121.40,.280,.589,.165,.457)]
ids=[h3.latlng_to_cell(a,b,5) for a,b,*_ in cells]
ed=[(i,j) for i in range(6) for j in range(i+1,6) if h3.are_neighbor_cells(ids[i],ids[j])]
V,C,R_,U=np.array([c[2:] for c in cells]).T
hd=1*C+.5*R_+.3*U-2*V
spd=DickeSpace(6,3,ed);Ed=spd.energies(hd,0.3);od=np.argmin(Ed)
b,pr=best_of(spd,Ed,4,100,4)
out['dixie']=dict(ids=ids,edges=ed,h=hd.tolist(),opt=''.join(map(str,spd.Z[od])),Estar=float(Ed.min()),Emean=float(b.fun),
    Popt=float(pr[od]),probs=pr.tolist(),Z=spd.Z.tolist(),E=Ed.tolist())
print(out['dixie']['edges'],out['dixie']['opt'],out['dixie']['Popt'])

b,pr=best_of(sp,E,4,100,1)
out['astro_dist']=dict(probs=pr.tolist(),Z=sp.Z.tolist(),E=E.tolist())
json.dump(out,open('sims.json','w'))

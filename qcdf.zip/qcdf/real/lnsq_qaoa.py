"""Thinning law with real quantum sub-solvers: the large-neighbourhood search of lnsq.py with constraint-preserving QAOA (Dicke state, window-graph XY mixer) as the window sub-solver, simulated exactly in the window subspace."""
import sys, os, json, math, time, numpy as np
from scipy.optimize import minimize
sys.path.insert(0, '../out')
from qcdf_scaling import DickeSpace
import lnsq as LQ
import qres as QR

ITERS = int(os.environ.get('LQQ_ITERS', 500)); SEEDS = int(os.environ.get('LQQ_SEEDS', 4))
PE, PB = 2, 3
_SP = {}

def space(W, P):
    key = tuple(W)
    if key not in _SP:
        loc = {c: a for a, c in enumerate(W)}
        edges = [(loc[c], loc[d]) for c in W for d in P.adj[c] if d in loc and loc[c] < loc[d]]
        _SP[key] = edges
    return _SP[key]

def qaoa_probs(E, w, k, edges, mode, warm, rng):
    sp = DickeSpace(w, k, edges); En = (E - E.mean()) / (E.std() + 1e-12)
    opt = np.where(En <= En.min() + 1e-9)[0]; mask = np.zeros(sp.dim); mask[opt] = 1.0
    p = PE if mode == 'E' else PB
    bnd = [(0, 2 * np.pi)] * p + [(0, np.pi)] * p
    fE = lambda x: QR.value_grad(x, sp, En, lambda v: En * v)
    def fP(x):
        pv, gv = QR.value_grad(x, sp, En, lambda v: mask * v); pv = max(pv, 1e-300); return -math.log(pv), -gv / pv
    starts = [np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)])]
    if warm.get(mode) is not None: starts.append(warm[mode])
    f = fE if mode == 'E' else fP
    best = min((minimize(f, x0, jac=True, method='L-BFGS-B', bounds=bnd, options={'maxiter': 200}) for x0 in starts), key=lambda r: r.fun)
    warm[mode] = best.x
    psi = QR.fwd_states(best.x, sp, En); pr = np.abs(psi) ** 2; pr = pr / pr.sum()
    return pr, float(pr[opt].sum())

def run(P, mode, seed, Z0, Eref, w, S):
    rng = np.random.default_rng(seed); Z = list(Z0); e = P.energy(Z); trace = []; pis = []; imp = []; used = 0; warm = {}
    for it in range(ITERS):
        W = LQ.window(P, rng, Z, w); pr_ = LQ.subproblem(P, W, Z)
        if pr_ is None: trace.append(e); continue
        used += 1; E = pr_['E']; k = int(pr_['Zm'][0].sum())
        probs, pi = qaoa_probs(E, len(W), k, space(W, P), mode, warm, rng); pis.append(pi); imp.append(bool(E.min() < pr_['e_cur'] - 1e-9))
        s = rng.choice(len(E), size=S, p=probs); a = int(s[np.argmin(E[s])])
        if E[a] < pr_['e_cur'] - 1e-9:
            Z = pr_['rest'] + [pr_['W'][j] for j in np.where(pr_['Zm'][a] == 1)[0]]; e = P.energy(Z)
        trace.append(e)
    return dict(gap=[(x - Eref) / abs(Eref) for x in trace], pi=pis, q=[1 - (1 - x) ** S for x in pis], imp=imp, used=used)

if __name__ == '__main__':
    dom, out = sys.argv[1], sys.argv[2]; cfgs = json.loads(sys.argv[3]); res = []; t0 = time.time()
    if os.path.exists(out): res = json.load(open(out))
    done = {(r['K'], r['w'], r['S'], r.get('T0', ''), r['mode'], r['seed']) for r in res}
    for c in cfgs:
        if dom == 'fire':
            import fullscale as FS
            P = FS.Problem(c['T0']).build_qubo(); P.eset = set(P.elig.tolist()); Z0 = list(P.elig[np.argsort(P.h[P.elig])[:c['K']]])
        else:
            sys.path.insert(0, '../astro'); import lnsq_astro as LA
            P = LA.Ham('../astro/astro_ham_prospective.pkl'); Z0 = list(np.argsort(P.h)[:c['K']])
        Zm, _ = P.milp(c['K']); Em = P.energy(Zm)
        for mode in ('E', 'B'):
            for seed in range(SEEDS):
                key = (c['K'], c['w'], c['S'], c.get('T0', ''), mode, seed)
                if key in done: continue
                r = run(P, mode, seed, Z0, Em, c['w'], c['S']); r.update(domain=dom, T0=c.get('T0', ''), K=c['K'], w=c['w'], S=c['S'], mode=mode, seed=seed)
                res.append(r); json.dump(res, open(out, 'w'))
                print(dom, key, 'gap', round(100 * r['gap'][-1], 2), 'q', round(float(np.mean(r['q'])), 3), 'pi', round(float(np.median(r['pi'])), 4), f'[{time.time()-t0:.0f}s]', flush=True)

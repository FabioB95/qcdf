"""Tokens and tables of the council round (v15), wildfire side: decision-time domain as primary, active-phase intervals on block means, simulation budget per rule, model x rule decomposition, calibration without clipping artefacts, per-residence DINS anticipation, random reference for recorded firelines."""
import json, math, os, numpy as np, pandas as pd
from scipy import stats
tok = {}
f1 = lambda x: f"{x:.1f}"; sg = lambda x: f"{x:+.1f}"
def blockci(d, size=2):
    d = np.asarray(d); m = np.array([d[i:i + size].mean() for i in range(0, len(d), size)]); n = len(m)
    h = stats.t.ppf(0.975, n - 1) * m.std(ddof=1) / math.sqrt(n); return d.mean(), d.mean() - h, d.mean() + h
def ci_txt(c): return f"${sg(c[0])}$ [${sg(c[1])}$, ${sg(c[2])}$]"
ACT = '2021-08-05'
PRIM = [('QCDF_h_only', 'fields only'), ('B4_value_at_risk', 'expected exposure'), ('CELF_greedy', 'simulator greedy')]
def contrasts(fn):
    R = sorted([r for r in json.load(open(fn)) if r['T0'] <= ACT], key=lambda r: r['T0'])
    v = lambda m, K='10': np.array([r['K'][K]['eval'][m]['saved_pct'] for r in R])
    return R, v, {m: blockci(v('QCDF_MILP') - v(m)) for m, _ in PRIM}
R0, v0, C0 = contrasts('fsP_act.json')
for m, _ in PRIM: tok[f'XV5_c_{m}'] = ci_txt(C0[m])
if os.path.exists('fsDT.json'):
    RD, vD, CD = contrasts('fsDT.json')
    for m, _ in PRIM: tok[f'XV5_dt_{m}'] = ci_txt(CD[m])
    for m in ('QCDF_MILP', 'QCDF_h_only', 'B4_value_at_risk', 'CELF_greedy', 'B1_communities', 'B2_nearest_front', 'B6_random', 'QCDF_SA'):
        tok[f'XV5_dts_{m}'] = f1(vD(m).mean())
    tok['XV5_dt_n'] = str(len(RD))
for m, _ in PRIM:
    d = v0('QCDF_MILP') - v0(m); tok[f'XV5_pos_{m}'] = f"{int((d > 0.05).sum())}/{len(d)}"
R_A, R_P, M_PAIR = 300, 1000, 120
bud = []
for r in R0:
    ne, npair = r['n_elig'], r['n_pairs']
    sur = (1 + ne) * R_A + (1 + min(M_PAIR, ne) + npair) * R_P
    celf = r['K']['10']['celf_evals'] * R_A
    bud.append((sur, celf, r['t_qubo'], r['K']['10']['t']))
bud = np.array(bud, float)
tok.update(XV5_bud_sur=f"{bud[:,0].mean()/1e3:.0f}", XV5_bud_celf=f"{bud[:,1].mean()/1e3:.0f}", XV5_bud_ratio=f"{(bud[:,0]/bud[:,1]).mean():.1f}",
           XV5_bud_tq=f"{bud[:,2].mean():.0f}", XV5_bud_va=f"{R_A/1e3:.1f}")
X = {m: {r['T0']: r for r in json.load(open(f'xev_{m}.json'))} for m in ('prospective', 'rolling')}
RULES = ['QCDF_MILP', 'B4_value_at_risk', 'CELF_greedy']; BUILD = ['prospective', 'rolling']
for ev in ('prospective', 'rolling'):
    dates = sorted(X[ev]); Y = np.array([[[float(X[ev][d][f'{b}|{m}']) for m in RULES] for b in BUILD] for d in dates])
    gm = Y.mean(); mb = Y.mean((0, 2)) - gm; mr = Y.mean((0, 1)) - gm
    inter = Y.mean(0) - gm - mb[:, None] - mr[None, :]
    ssb = Y.shape[0] * Y.shape[2] * (mb ** 2).sum(); ssr = Y.shape[0] * Y.shape[1] * (mr ** 2).sum(); ssi = Y.shape[0] * (inter ** 2).sum()
    tot = ssb + ssr + ssi; e = ev[:3]
    tok[f'XV5_dec_{e}_b'] = f"{100*ssb/tot:.0f}"; tok[f'XV5_dec_{e}_r'] = f"{100*ssr/tot:.0f}"; tok[f'XV5_dec_{e}_i'] = f"{100*ssi/tot:.0f}"
    eff = Y[:, 0, :].mean(1) - Y[:, 1, :].mean(1); tok[f'XV5_dec_{e}_beff'] = ci_txt(blockci(eff))
    off = 'rolling' if ev == 'prospective' else 'prospective'; bo = BUILD.index(off)
    tok[f'XV5_off_{e}'] = ci_txt(blockci(Y[:, bo, 0] - Y[:, bo, 1]))
C = pd.read_csv('calib_check_v12_cells.csv.gz'); C = C[(C.model == 'prospective') & (C.T0 <= ACT)]
pmin = C.p.min(); z = C.p <= pmin + 1e-12
tok['XV5_cal_zero'] = f"{100*z.mean():.0f}"; tok['XV5_cal_zero_burn'] = f"{100*C[z].y.sum()/C.y.sum():.0f}"
def slope(df, clip):
    lp = np.log(np.clip(df.p, clip, 1 - clip) / (1 - np.clip(df.p, clip, 1 - clip)))
    from sklearn.linear_model import LogisticRegression
    return LogisticRegression(C=1e6).fit(lp.values[:, None], df.y.values).coef_[0, 0]
tok['XV5_cal_slope_pos'] = f"{slope(C[~z], 1e-6):.2f}"; tok['XV5_cal_slope_c2'] = f"{slope(C, 1e-2):.2f}"
bins = np.r_[0, 0.0015, 0.01, 0.03, 0.1, 0.3, 1.0001]; C = C.assign(b=pd.cut(C.p, bins, right=False))
g = C.groupby('b', observed=True).agg(n=('y', 'size'), py=('p', 'mean'), oy=('y', 'mean')); ybar = C.y.mean()
rel = float((g.n * (g.py - g.oy) ** 2).sum() / len(C)); res_ = float((g.n * (g.oy - ybar) ** 2).sum() / len(C)); unc = ybar * (1 - ybar)
tok.update(XV5_rel=f"{rel:.4f}", XV5_res=f"{res_:.4f}", XV5_unc=f"{unc:.4f}")
D = json.load(open('dins_v15.json')); dr = D['res']['fsP_act.json']; tok['XV5_gv_res'] = str(D['GV_res'])
lab = {'B6_random': 'random (one draw)', 'B1_communities': 'communities first', 'B2_nearest_front': 'nearest to front',
       'B4_value_at_risk': 'expected exposure', 'QCDF_h_only': 'QCDF, $J=0$', 'QCDF_MILP': 'QCDF, exact', 'CELF_greedy': 'simulator greedy'}
rows = []
for m, l in lab.items():
    a, b = dr[f'{m}_L1'], dr[f'{m}_L2']
    rows.append(f"{l} & {a['n']} ({100*a['share']:.0f}\\%) & {b['n']} ({100*b['share']:.0f}\\%) & {b['n_noGV']} ({100*b['share_noGV']:.0f}\\%) \\\\")
t2 = dr['QCDF_MILP_L2']
tok['XV5_DINSTAB'] = (r"""\begin{table}[!htbp]
\centering
\caption{Anticipation of the destroyed residences, each counted once (Dixie,
active phase, $K=10$, prospective model). A residence destroyed in cell $c$ on
day $t_c$ is anticipated by a rule if $c$ was in its plan on a decision date
$T_0$ with $T_0+L\le t_c\le T_0+10$. Denominators: """ + f"{dr['QCDF_MILP_L1']['tot']}" + r""" residences ($L=1$),
""" + f"{t2['tot']}" + r""" ($L=2$), of which """ + f"{t2['tot']-t2['tot_noGV']}" + r""" in the Greenville cell. Covering a
cell where houses were later destroyed shows anticipation of the loss, not that
the loss was reduced.}
\label{tab:dins}
\footnotesize
\begin{tabular}{lrrr}
\toprule
Rule & $L=1$ day & $L=2$ days & $L=2$, without Greenville \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}""")
for m in lab:
    tok[f'XV5_d2_{m}'] = f"{100*dr[f'{m}_L2']['share']:.0f}"; tok[f'XV5_d2x_{m}'] = f"{100*dr[f'{m}_L2']['share_noGV']:.0f}"; tok[f'XV5_d1_{m}'] = f"{100*dr[f'{m}_L1']['share']:.0f}"
FL = json.load(open('fireline.json'))['plan_overlap_active']['frac_line_10d']; tok['XR_fl_rand'] = f"{100*FL['B6_random']:.0f}"

A = json.load(open('../astro/astro_v15.json'))
for c, pre in (('main', 'XA5'), ('rep', 'XA5R')):
    x = A[c]; f2 = lambda v: f"{v:.2f}"
    tok.update({f'{pre}_auc_model': f2(x['auc']['model']), f'{pre}_auc_curv': f2(x['auc']['curv']), f'{pre}_auc_sig': f2(x['auc']['signif']),
                f'{pre}_auc_beta': f2(x['auc']['lp_beta']), f'{pre}_auc_cls': f2(x['auc']['classifier']),
                f'{pre}_dsig': f"[{x['auc_diff_ci']['signif'][0]:+.2f}, {x['auc_diff_ci']['signif'][1]:+.2f}]",
                f'{pre}_dcurv': f"[{x['auc_diff_ci']['curv'][0]:+.2f}, {x['auc_diff_ci']['curv'][1]:+.2f}]",
                f'{pre}_oe': f"{x['oe'][0]:.2f} [{x['oe'][1]:.2f}, {x['oe'][2]:.2f}]", f'{pre}_slope': f"{x['slope'][0]:.2f} [{x['slope'][1]:.2f}, {x['slope'][2]:.2f}]",
                f'{pre}_npsr': str(x['n_psr']), f'{pre}_npos': str(x['n_pos']), f'{pre}_dec_tgt': str(x['dec']['targets_above']), f'{pre}_dec_ntgt': f"{x['dec']['n_targets']:,}".replace(',', '{,}'),
                f'{pre}_dec_pos': str(x['dec']['pos_above']), f'{pre}_dec_p': f"{x['dec']['p_zero']:.3f}"})
    T = x['tiling']['res']
    for k in ('QCDF', 'curvature', 'brightest', 'classifier'):
        for K in (50, 200): tok[f'{pre}_t_{k}_{K}'] = str(T[f'{k}|{K}']['pos']); tok[f'{pre}_tp_{k}_{K}'] = str(T[f'{k}|{K}']['psr'])
    for K in (50, 200): tok[f'{pre}_t_rand_{K}'] = f"{T[f'random|{K}']['pos']:.1f}$\\pm${T[f'random|{K}']['pos_sd']:.1f}"
    tok[f'{pre}_t_ncand'] = f"{x['tiling']['n_cand']:,}".replace(',', '{,}'); tok[f'{pre}_t_pairs'] = str(x['tiling']['overlapping_pairs'])
    X_ = x['xev']
    for kk, v in X_.items(): tok[f"{pre}_x_{kk.replace('|', '_')}"] = (f"{v['pos']:.1f}" if isinstance(v['pos'], float) else str(v['pos']))
cf = A['main']['coef']; ci = A['main']['coef_ci']; cfr = A['rep']['coef']; cir = A['rep']['coef_ci']
nm = dict(logF='log flux', idx='photon index', curv='curvature significance', logvar='log variability', absb='$|b|$', logerr='log error radius', logsig='log significance')
crow = "\n".join(f"{nm[k]} & ${cf[k]:+.2f}$ [${ci[k][0]:+.2f}$, ${ci[k][1]:+.2f}$] & ${cfr[k]:+.2f}$ [${cir[k][0]:+.2f}$, ${cir[k][1]:+.2f}$] \\\\" for k in nm)
def xr(c, f, K): v = A[c]['xev'][f'{f}|{K}']; return f"{v['pos']}/{v['psr']}"
xrows = []
for f, l in (('model', 'prospective model'), ('classifier', 'pulsar--AGN classifier'), ('retrospective', 'retrospective model (in-sample)')):
    xrows.append(f"{l} & " + " & ".join(f"{xr(c, f + '|QCDF', K)} & {xr(c, f + '|rank', K)}" for c in ('main',) for K in (50, 200)) + " \\\\")
xrows.append("curvature significance & -- & " + xr('main', 'curvature|rank', 50) + " & -- & " + xr('main', 'curvature|rank', 200) + " \\\\")
xrows.append("random (mean) & \\multicolumn{2}{c}{" + f"{A['main']['xev']['random|50']['pos']:.1f}/{A['main']['xev']['random|50']['psr']:.1f}" + "} & \\multicolumn{2}{c}{" + f"{A['main']['xev']['random|200']['pos']:.1f}/{A['main']['xev']['random|200']['psr']:.1f}" + "} \\\\")
tok['XA5_XEVTAB'] = r"""\begin{table}[!htbp]
\centering
\caption{Sky campaign DR3$\to$DR4, forecast $\times$ rule: newly associated
sources / new pulsars covered by plans built from each forecast with the exact
QCDF optimum or by ranking the sources and pointing at the best pixel of each
(paper's beam model). Changing the forecast moves the count far more than
changing the rule.}
\label{tab:skyxev}
\footnotesize
\begin{tabular}{lcccc}
\toprule
 & \multicolumn{2}{c}{$K=50$} & \multicolumn{2}{c}{$K=200$} \\
\cmidrule(lr){2-3}\cmidrule(lr){4-5}
Forecast & QCDF & rank & QCDF & rank \\
\midrule
""" + "\n".join(xrows) + r"""
\bottomrule
\end{tabular}
\end{table}"""
tok['XA5_COEFTAB'] = r"""\begin{table}[!htbp]
\centering
\caption{Standardised coefficients of the identification model (95\% bootstrap
intervals over the training sources) for the main campaign (fitted on
DR2$\to$DR3) and the replication (fitted on DR1$\to$DR2). Detection
significance carries the model; curvature significance does not enter it
once significance is included.}
\label{tab:skycoef}
\footnotesize
\begin{tabular}{lcc}
\toprule
Feature & main campaign & replication \\
\midrule
""" + crow + r"""
\bottomrule
\end{tabular}
\end{table}"""
json.dump({k: v for k, v in tok.items() if 'TAB' not in k}, open('v15_tokens.json', 'w'), indent=1)
fn = '../paper/v4_body_filled.tex'; s = open(fn).read()
for k_, v in sorted(tok.items(), key=lambda kv: -len(kv[0])): s = s.replace('@@' + k_ + '@@', v)
open(fn, 'w').write(s)
print({k: v for k, v in tok.items() if 'TAB' not in k})

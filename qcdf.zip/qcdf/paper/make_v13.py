"""Assemble the v13 body (main text + Supplementary Material) from the v13 templates and verbatim blocks of the frozen v12 body."""
import re
F = open('v13/v12_body_frozen.tex').read().split('\n')
L = lambda a, b: '\n'.join(F[a - 1:b])
parts = [open(f'v13/{p}.tex').read() for p in ('main_a', 'main_b', 'main_c', 'main_d', 'sm')]
body = '\n'.join(parts)
body = re.sub(r'%%L (\d+) (\d+)%%', lambda m: L(int(m.group(1)), int(m.group(2))), body)

FIX = [
 ("Appendices~\\ref", "Supplementary Sections~\\ref"), ("Appendix~\\ref", "Supplementary Section~\\ref"),
 ("checked classically in $O(N)$, so infeasible shots --- which on hardware\narise only from gate and readout errors (Proposition~\\ref{prop:conservation})\n--- can be discarded exactly and at no cost.",
  "checked classically in $O(N)$, so infeasible shots --- which on hardware\narise only from gate and readout errors (Proposition~\\ref{prop:conservation})\n--- can be discarded exactly. Post-selection needs no extra circuit, but\nthe discarded shots are lost: it raises the probability of the optimum among\nthe accepted shots, not the number of optimal samples per shot\n(Section~\\ref{sec:hardware})."),
 ("Budgets vs.\\ reinforcements & $K=5$ then $+5$, $K=10$ then $+10$ & $K=20$ then extended to 50 \\\\",
  "Two-stage completion & $K=5$ completed to 10 and $K=10$ to 20, at the same date & $K=20$ completed to 50 \\\\"),
 ("$n$: those sources with any beam response.", "$n$: those sources covered (at least one pointing with mean beam response above $1\\%$,\nSection~\\ref{sec:astro_case})."),
 ("LNS quantum layer (\\S\\ref{sec:dixie_res}) & windows of 16 & exact, $p=0$, QAOA, anneal & anneal $\\approx$ exact; QAOA $\\approx$ uniform & synthetic $q$-oracle \\\\",
  "Sky campaign (\\S\\ref{sec:astro_full}) & 8{,}576 cells, $K\\le200$ & MILP & @@XA_q200@@ of @@XA_postest@@ DR4 sources covered ($K=200$) & brightness @@XA_b200@@, curvature @@XA_c200@@ \\\\\n"
  "Quantum layer (\\S\\ref{sec:quantum}) & windows, $|\\feasible_k(W)|\\le4{,}845$ & exact, $q$-oracle, QAOA $p\\le10$ & thinning law verified; QAOA gives a constant amplification & uniform; amplitude amplification \\\\"),
 ("$\\approx$ value at risk; closed loop $2\\times$ open", "$\\approx$ value at risk; re-planning $+@@XW_gain_seq@@$ pts (forward)"),
 ("Caldor replication (\\S\\ref{sec:caldor})", "Caldor, Monument (\\S\\ref{sec:dixie_res})"),
 ("the allocation policy is\ntested on two fires.", "the allocation policy is\ntested on three fires."),
 ("\\paragraph{Budgets and reinforcements.}", "\\paragraph{Budgets and two-stage completion.}"),
 ("Adding units to a plan already in place\n(five, then five more chosen given the first five)",
  "Completing a plan in two stages at the same date (five units, then five\nmore chosen given the first five; no time passes between the stages)"),
 ("In this model, reinforcements that\narrive later and are added to the plan in place lose nothing against a\nbudget known from the start.",
  "The plan can therefore be completed in stages without loss. This is a\ntest of two-stage completion, not of reinforcements that arrive later and\nface a fire that has moved, which is not modelled."),
 ("the paragraphs below discuss the three that\nchange the reading of the paper, and the appendices give the details.", "the paragraphs below discuss those that\nchange the reading of the paper, and the Supplementary Material gives the details."),
 ("\\begin{table}[t]\n\\centering\n\\caption{Outcome of the validation protocol", "\\begin{table}[!htbp]\n\\centering\n\\caption{Outcome of the validation protocol"),
 ("\\subsection{Hardware execution (preliminary observation)}", "\\section{Hardware execution (preliminary observation)}"),
 ("\\paragraph{The quantum layer at full scale.} The full problem", "\\paragraph{Large-neighbourhood search on the wildfire Hamiltonian.}\\label{sm:lns} The full problem"),
 ("\\paragraph{Conditional effectiveness, access and critical facilities.}\n@@XP_OPSTEXT@@",
  "\\paragraph{Conditional effectiveness, access and critical facilities.}\n@@XP_OPSTEXT@@\n\n"
  "\\emph{The conditional model.} In the conditional variant a protected cell\n$j$ multiplies the ignition probability of each incoming edge by\n$1-\\eta_j(t)$, with\n"
  "\\[\n  \\eta_j(t)=\\frac{0.85}{1+\\big(\\nu_j(t)/6\\,\\mathrm{m\\,s^{-1}}\\big)^2}\\,\\Big[1-0.5\\min\\big(1,s_j/0.3\\big)\\Big],\n\\]\n"
  "where $\\nu_j(t)$ is the daily wind speed at the cell and $s_j$ the largest\nabsolute slope (rise over run) to a neighbour. The reduction acts per edge,\n$q_{ij}\\to q_{ij}(1-\\eta_j)$, so a cell with $m$ burning neighbours burns\nwith probability $1-\\prod_i[1-q_{ij}(1-\\eta_j)]$, which for $m>1$ is not\n$(1-\\eta_j)$ times its unprotected burn probability; the constant-$\\eta$\nmodel of the main text acts in the same way."),
]
FIX += [
 ("b_S\\,S_{ij} + b_D\\,D_j(t)\\big),", "b_S\\,S_{ij} + b_D\\,D_j(t) + b_E\\,E_j(t)\\big),"),
 ("couplings within two standard errors of zero are set to zero). A negative", "couplings within two standard errors of zero are set to zero; we write\n$I_{ij}=-J_{ij}$ for the measured interaction). A negative"),
 ("wind, slope, VPD help; dryness, De Martonne null", "wind, slope help; VPD partly; dryness, De Martonne null"),
 ("(Sections~\\ref{sec:penalty}--\\ref{sec:tts}), and $75.95\\%$", "(Section~\\ref{sec:small}), and $75.95\\%$"),
 ("($1.7$--$2.3\\times$ over the local\nminima of Section~\\ref{sec:pilot})", "($1.0$--$2.1\\times$ over the local\nminima of Section~\\ref{sec:pilot})"),
 (" and @@XV_p30zero@@\\% of the 30-day ones), and", "), and"),
 ("(calibration slopes\n$0.17$--$0.28$, Section~\\ref{sec:calibres})", "(calibration slopes\n$0.17$--$0.28$, Table~\\ref{tab:cal})"),
 ("greedy search on the\nsimulator, which needs about @@XF_cevals_10@@ simulator calls per date\nagainst the several hundred needed to build the Hamiltonian, is better by\n@@XV_dall_CELF_greedy_prospective@@ points (interval\n@@XV_ci_CELF_greedy_prospective@@) --- the error of the pairwise\nsurrogate.",
  "greedy search on the\nsimulator is ahead of the exact plan (QCDF minus greedy\n@@XV_dall_CELF_greedy_prospective@@ points, interval\n@@XV_ci_CELF_greedy_prospective@@) --- the error of the pairwise\nsurrogate."),
 ("Simulated annealing in $\\feasible_K$ reaches the exact\noptimum of the surrogate on every date, so its rows coincide with the exact\nplan.}", "Simulated annealing in $\\feasible_K$ reaches the exact\noptimum of the surrogate on every date under the prospective model; under\nthe rolling model it misses it on some dates (52.6 against 52.8).}"),
 (": an improving fallback only\nhelps.", ": in these runs an improving\nfallback did not slow the search."),
 ("observed one in @@XQ_agree@@\\% of configurations, so it is a safe design\nvalue.", "observed one in @@XQ_agree@@\\% of configurations, so it is a conservative\ndesign value in most, not all, configurations."),
 ("(16 members each, three\ndates, ten splits)", "(15 or 16 members each,\nthree dates, ten splits)"),
 ("and the allocation\ncomparison is unchanged: @@XP_rc_alloc@@.", "and under it\n@@XP_rc_alloc@@: the coupling gain survives, the small margin over value at\nrisk does not."),
 ("is the rolling model of\nSection~\\ref{sec:calibres}.", "is the rolling model of\nSection~\\ref{sec:dixie_res}."),
 ("$@@XP_st_cv@@$): precision of the simulator is not the limiting factor;\nthe number of independent fires is.", "$@@XP_st_cv@@$). The unpaired bound overstates the noise of the paired\ndifferences, which share their random numbers; the difference between\nfires, the largest of the three, is what limits the conclusions."),
 ("identified sources covered). Each variant re-optimises the plan.}", "identified sources covered). Each variant re-optimises the plan by lazy\ngreedy on the exact coverage objective (submodular), so the ``main'' row is\nthe greedy plan of Table~\\ref{tab:astro_full}.}"),
 ("\\citep{venturelli2016scheduling, booth2021scheduling}", "\\citep{venturelli2016scheduling}"),
 ("\\paragraph{Closed loop.} Re-planning at every observed perimeter matters\nfar more than the choice of optimiser.", "\\paragraph{Closed loop re-anchored on the observed perimeter.} In this\ncomparison re-planning matters more than the choice of optimiser, but most of\nthat is the value of observing the real fire (Section~\\ref{sec:dixie_res})."),
 ("Numerically (Supplementary Section~\\ref{app:bound})", "Numerically (Figure~\\ref{fig:bound})"),
]
FIX += [('\\begin{equation}\n  q_{ij}(t) = \\sigma\\big(b_0 + b_W\\,W_{ij}(t) + b_S\\,S_{ij} + b_D\\,D_j(t) + b_E\\,E_j(t)\\big),\n  \\qquad\n  W_{ij}(t) = \\nu_i(t)\\cos\\!\\big(\\theta_{ij}-\\omega_i(t)\\big),\\quad\n  S_{ij} = \\frac{z_j-z_i}{d_{ij}},\n  \\label{eq:spread}\n\\end{equation}', '\\begin{gather}\n  q_{ij}(t) = \\sigma\\big(b_0 + b_W\\,W_{ij}(t) + b_S\\,S_{ij} + b_D\\,D_j(t) + b_E\\,E_j(t)\\big),\\nonumber\\\\\n  W_{ij}(t) = \\nu_i(t)\\cos\\!\\big(\\theta_{ij}-\\omega_i(t)\\big),\\quad\n  S_{ij} = \\frac{z_j-z_i}{d_{ij}},\n  \\label{eq:spread}\n\\end{gather}')]
FIX += [
 ("$1-\\eta$, $\\eta=0.85$,\nan assumption.", "$1-\\eta$, $\\eta=0.85$,\nan assumption. It is optimistic: the fireline archive classifies 23\\% of\nthe Dixie line as held and 39\\% as burned over (about 37\\% held among\nengaged line; Supplementary Section~\\ref{app:protocol_fire}), so a variant\nwhose effectiveness falls with wind and slope (mean 0.52) is reported\nalongside as a hypothetical lower-effectiveness scenario: the held share\ndoes not measure the daily reduction of transmission, so it does not\ncalibrate $\\eta$."),
 ("Because the spread model was calibrated on\nperimeters that already reflect the suppression effort of 2021, every\nsaving reported below is the \\emph{marginal} value of $K$ additional units\non top of that effort, inside the calibrated model, and every comparison is\nbetween allocations of the same $K$.",
  "Every saving reported below is the \\emph{marginal} value of $K$ additional\nunits on top of the suppression implicit in the perimeters the model was\nfitted on (the 2019--2020 fires for the prospective model, Dixie's own for\nthe rolling and retrospective models), inside the calibrated model, and every\ncomparison is between allocations of the same $K$."),
 ("effectiveness, on top of the 2021 suppression effort. They compare", "effectiveness, on top of the suppression implicit in the training\nperimeters. They compare"),
 ("effectiveness $\\eta$, and are marginal to the 2021 suppression effort\nalready contained in the calibration data; they are not estimates of\nhouses that would have been saved.", "effectiveness $\\eta$, and are marginal to the suppression implicit in the\ntraining perimeters; they are not estimates of houses that would have been\nsaved."),
 ("answer depends on size (Section~\\ref{sec:penalty}). This is the kind of\nhead-to-head comparison that most applied QAOA studies omit.", "answer depends on size (Section~\\ref{sec:penalty}). Such comparisons have\nbeen made in simulation and on hardware\n\\citep{niroula2022constrained, he2023alignment}; ours adds them on the\ninstances of a full-scale pipeline."),
 ("A spatial grid is a graph $\\mathcal{G}=(\\lattice,\\mathcal{E})$ with", "A QCDF instance is a quadratic objective on a spatial graph, restricted to\nthe plans that select exactly $k$ cells,\n\\begin{equation}\n  \\min_{z\\in\\{0,1\\}^N}\;\\sum_i h_i z_i+\\sum_{(i,j)\\in\\mathcal{E}}J_{ij}z_iz_j\n  \\quad\\text{s.t.}\\quad\\sum_i z_i=k,\n  \\label{eq:qcdf_general}\n\\end{equation}\nwhose fields and couplings are derived from a decision model fitted only on\npast data: measured on a simulator in the wildfire study, read off the beam\ngeometry in the sky study.\nA spatial grid is a graph $\\mathcal{G}=(\\lattice,\\mathcal{E})$ with"),
]
FIX += [
 ("sub-solver inside large-neighbourhood search at full scale. Every plan\n  is evaluated on held-out simulator realisations.}", "sub-solver inside large-neighbourhood search at full scale. Wildfire plans\n  are evaluated on held-out simulator realisations and against the damage\n  records; sky plans against the sources associated in the next catalogue\n  release.}"),
 ("and since every edge gate appears, the reachable set on $\\feasible_k$ is the\nsame connected token graph.", "and since every edge gate appears in each layer, a product of layers moves\ntokens along any path of the token graph \\citep{fabila2012token}. A single\nlayer, however, moves them only along subsequences of edges in the gate\norder, so every feasible string is reachable for $p$ at least the token\ndistance, not necessarily at $p=1$ (cf.\\ the reachability deficits of\n\\citealp{akshay2020reachability})."),
 ("guarantee. Quantum models\nof human decision making \\citep{busemeyer2012quantum, pothos2013can} use\nquantum probability descriptively; QCDF instead uses quantum dynamics as a\nsolver for a decision problem.", "guarantee."),
 ("\\subsection{Hamiltonian}\nThe physical Hamiltonian", "\\subsection{Hamiltonian of the pilot}\nThe physical Hamiltonian"),
]
FIX += [
 ("DINS: share of the residences destroyed within 10 days\n(CAL FIRE records) that lay in protected cells ($K=10$, pooled).", "DINS: share of the destroyed residences, each counted once, whose cell was\nin the plan at least two days before it burned and within the horizon\n($K=10$; Table~\\ref{tab:dins})."),
]
FIX += [
 ("beam efficiency, value weights). Second, a plan is built only from\ninformation available at the decision; information from later is used\nonly to evaluate it.", "beam efficiency, value weights). Second, a plan should be built only from\ninformation available at the decision; information from later is used\nonly to evaluate it. In the wildfire hindcast the three later inputs (final\nperimeter, observed weather, Census 2020) are replaced one at a time in\nseparate checks, not in one joint replay (Section~\\ref{sec:dixie_res})."),
]
FIX += [
 ("the 12 dates are not independent) and DINS\ncoverage ($K=10$).}", "the 12 dates are not independent) and destroyed residences anticipated\n($K=10$; each residence counted once, cell in the plan at least two days\nbefore it burned and within the ten-day horizon, as in Table~\\ref{tab:dins}).}"),
 ("DINS coverage of the forecast-driven plans (@@XV_cald_dcov_qcdf@@\\% for QCDF)\nis close to that of ``communities first'' (@@XV_cald_dcov_comm@@\\%), unlike on\nDixie --- plausibly because Grizzly Flats lay on the path of the early run,\nwhere the forecast was informative.", "share of destroyed residences anticipated by the forecast-driven plans\n(@@XV_cald_dcov_qcdf@@\\% for QCDF) is of the same order as that of ``communities\nfirst'' (@@XV_cald_dcov_comm@@\\%) though below the expected-exposure ranking\n(@@XV_cald_dcov_var@@\\%), unlike on Dixie (@@XV_dix_dcov_qcdf@@\\% against\n@@XV_dix_dcov_comm@@\\%); one cell holds most of them, and without it the shares are\n@@XV_cald_dcov_qcdf_nox@@\\% and @@XV_cald_dcov_comm_nox@@\\%. Plausibly Grizzly Flats lay on the path of the\nearly run, where the forecast was informative."),
]
FIX += [
 ("(@@XF_lns_q@@): a sub-solver needs $q\\gtrsim0.3$ to match exact\nenumeration in this loop, which the anneal achieves and fixed-depth QAOA\ndoes not.", "(@@XF_lns_q@@): a sub-solver needs $q\\gtrsim0.1$ to match exact\nenumeration in this loop. The anneal reaches it; the final gaps of uniform\nsampling and of the transferred QAOA lie between those of $q=0.02$ and\n$q=0.1$ (the mean probabilities above average over windows of very\ndifferent sizes)."),
 ("on its starting plan (@@XF_lns_ev_LNS_exact@@--@@XF_lns_ev_LNS_uniform@@\\%", "on its starting plan (@@XF_lns_ev_lo@@--@@XF_lns_ev_hi@@\\%"),
]
FIX += [("full-scale Hamiltonian ($K=20$,\n  windows of 16 cells, @@XF_lns_n@@ dates, 3 seeds).", "full-scale Hamiltonian (prospective\n  model, $K=20$, windows of 16 cells, @@XF_lns_n@@ dates, 3 seeds).")]
FIX += [("houses). In the $\\hat n$ basis this is the paper's Hamiltonian with\nheterogeneous couplings: since $J\\sigma^z_i\\sigma^z_j=J-2J\\hat n_i-2J\\hat\nn_j+4J\\hat n_i\\hat n_j$, it corresponds to $J^{\\sigma}_{ij}=J_{ij}/4$ with\nfields shifted by $\\tfrac12\\sum_j J_{ij}$; the uniform $J$ of\nSection~\\ref{sec:formulation} is a special case.", "houses). This is the objective~\\eqref{eq:hdiag} directly, in the $\\hat n$\nbasis; the circuits use its spin form (Section~\\ref{sec:formulation}).")]
for a, b in FIX:
    n = body.count(a)
    if n == 0: raise SystemExit('FIX not found: ' + a[:80])
    body = body.replace(a, b)

fl_a = body.index('\\paragraph{Real containment lines.}'); fl_b = body.index('\\paragraph{A third fire.}')
body = body[:fl_a] + r"""\paragraph{Real containment lines.} The USFS fireline engagement archive
\citep{arkowitz2025fireline} holds, for the Dixie Fire, line records whose
lengths sum to @@XR_fl_km@@\,km after removing exactly repeated geometries
(by record length, @@XR_fl_dozer@@\% dozer line and @@XR_fl_road@@\% roads
used as line; @@XR_fl_held@@\% classified as held, @@XR_fl_burned@@\% as
burned over and @@XR_fl_not@@\% as not engaged). This sum is not the
physical length of the network, because many records are redrawn or
partially overlapping versions of the same line: merging overlapping
segments (noded union) leaves @@XR_fl_km_noded@@\,km, and merging all
segments within 10\,m (25\,m) of each other leaves an equivalent length,
from the area of the buffered corridors, of about
@@XR_fl_km_u10@@\,km (@@XR_fl_km_u25@@\,km), not a fused centre-line network. No segment has
a construction date (the field is empty); the only date is when a segment
was entered in the database, which ranges from @@XR_fl_d0@@ to
@@XR_fl_d1@@ (@@XR_fl_kmact@@\,km of record length entered by 5 August). The
engagement class is assigned against the final perimeter. The archive
therefore shows where lines were recorded, not when they were built, and
cannot identify the effect of a unit. As a descriptive check,
@@XR_fl_qcdf@@\% of the cells chosen by QCDF ($K=10$, active phase) contain
at least 100\,m of line records first entered in the database in the
following ten days, against @@XR_fl_var@@\% for value at risk,
@@XR_fl_front@@\% for the cells nearest the front and @@XR_fl_comm@@\% for
communities first. The forecast-driven plans and the front rule point at the
ground where line was recorded; the measure does not distinguish QCDF from
the front rule, and it does not show that the model anticipates the
deployment of crews.

""" + body[fl_b:]
open('v4_body.tex', 'w').write(body)
print('v13 body', len(body), 'chars;', body.count('\\includegraphics') + body.count('\\input{figures'), 'figure inputs')

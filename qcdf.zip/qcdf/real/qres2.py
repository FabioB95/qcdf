"""Resource estimate, second pass: mixer classes and the success target that matters inside the search."""
import sys, os, json, math, time, numpy as np
from scipy.optimize import minimize
sys.path.insert(0, '../out')
from qcdf_scaling import DickeSpace
import qres as QR

PMAX, RESTARTS = int(os.environ.get('Q2_PMAX', 10)), int(os.environ.get('Q2_RESTARTS', 5))
DMAX = int(os.environ.get('Q2_DMAX', 1820)); NPER = int(os.environ.get('Q2_NPER', 4))

def grover_state(x, E, D):
    p = len(x) // 2; psi = D.astype(complex).copy()
    for g, b in zip(x[:p], x[p:]):
        psi = psi * np.exp(-1j * g * E); psi = psi + (np.exp(-1j * b) - 1) * np.vdot(D, psi) * D
    return psi

def make(kind, w, k, edges, E):
    if kind == 'grover':
        dim = math.comb(w, k); D = np.full(dim, 1 / math.sqrt(dim))
        st = lambda x: grover_state(x, E, D)
        def vg(x, O):
            f0 = float(np.real(np.vdot(st(x), O * st(x)))); g = np.zeros(len(x)); h = 1e-6
            for i in range(len(x)):
                y = x.copy(); y[i] += h; s = st(y); g[i] = (float(np.real(np.vdot(s, O * s))) - f0) / h
            return f0, g
        return dim, st, vg
    ed = edges if kind == 'xyw' else [(a, b) for a in range(w) for b in range(a + 1, w)]
    sp = DickeSpace(w, k, ed)
    return sp.dim, (lambda x: QR.fwd_states(x, sp, E)), (lambda x, O: QR.value_grad(x, sp, E, lambda v: O * v))

def run(win, kind, rng):
    w, k = len(win['W']), win['ks']; E0 = np.array(win['E']); E = (E0 - E0.mean()) / (E0.std() + 1e-12)
    dim, st, vg = make(kind, w, k, win['edges'], E)
    opt = np.where(E <= E.min() + 1e-9)[0]; mopt = np.zeros(dim); mopt[opt] = 1.0
    imp = np.where(E0 < E0[win['cur']] - 1e-9)[0]; mimp = np.zeros(dim); mimp[imp] = 1.0
    fE = lambda x: vg(x, E)
    def fP(x):
        pv, gv = vg(x, mopt); pv = max(pv, 1e-300); return -math.log(pv), -gv / pv
    bnd = lambda p: [(0, 2 * np.pi)] * p + [(0, np.pi)] * p
    out = []; prevE = prevP = None
    for p in range(1, PMAX + 1):
        pad = lambda x: np.concatenate([x[:p - 1], [0.0], x[p - 1:], [0.0]])
        rs = lambda: np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)])
        sE = ([pad(prevE)] if prevE is not None else []) + [rs() for _ in range(RESTARTS)]
        bE = min((minimize(fE, x0, jac=True, method='L-BFGS-B', bounds=bnd(p), options={'maxiter': 300}) for x0 in sE), key=lambda r: r.fun)
        sP = [bE.x] + ([pad(prevP)] if prevP is not None else []) + [rs() for _ in range(RESTARTS)]
        bP = min((minimize(fP, x0, jac=True, method='L-BFGS-B', bounds=bnd(p), options={'maxiter': 300}) for x0 in sP), key=lambda r: r.fun)
        prevE, prevP = bE.x, bP.x
        pr = np.abs(st(bE.x)) ** 2; pr = pr / pr.sum()
        out.append(dict(p=p, A_E=float(pr[opt].sum()) * dim / len(opt), A_B=math.exp(-bP.fun) * dim / len(opt),
                        Pimp_E=float(pr[imp].sum()) if len(imp) else None))
    return dict(dim=dim, w=w, k=k, nopt=len(opt), nimp=int(len(imp)), mixer=kind, layers=out)

def add_cur(dom, wins):
    import qres as Q
    if dom == 'fire':
        import fullscale as FS
        P = FS.Problem('2021-08-04').build_qubo(); P.eset = set(P.elig.tolist()); Z0 = list(P.elig[np.argsort(P.h[P.elig])[:20]])
    else:
        import pickle
        d = pickle.load(open('../astro/astro_ham_prospective.pkl', 'rb'))
        class Ham: pass
        P = Ham(); P.h, P.J, P.adj = d['h'], d['J'], d['adj']; P.elig = np.arange(len(P.h)); P.eset = set(range(len(P.h)))
        Z0 = list(np.argsort(P.h)[:50])
    P.Jn = {}
    for (i, j), v in P.J.items():
        P.Jn.setdefault(i, []).append((j, v)); P.Jn.setdefault(j, []).append((i, v))
    got = Q.collect(P, Z0); new = [x for s in Q.SIZES for x in got[s]]
    for a, b in zip(wins, new):
        assert a['W'] == b['W'] and abs(a['E'][0] - b['E'][0]) < 1e-6
        a['cur'] = int(b['cur'])
    return wins

if __name__ == '__main__':
    dom, out = sys.argv[1], sys.argv[2]; t0 = time.time(); rng = np.random.default_rng(11)
    src = json.load(open(f'qres_{dom}.json')); wins = src['wins']
    if 'cur' not in wins[0]: wins = add_cur(dom, wins); src['wins'] = wins; json.dump(src, open(f'qres_{dom}.json', 'w'))
    res = json.load(open(out)) if os.path.exists(out) else []
    done = {(r['i'], r['mixer']) for r in res}
    seen = {}
    for i, win in enumerate(wins):
        if math.comb(len(win['W']), win['ks']) > DMAX: continue
        cls = (len(win['W']), win['ks']); seen[cls] = seen.get(cls, 0) + 1
        if seen[cls] > NPER: continue
        for kind in ('xyw', 'xyc', 'grover'):
            if (i, kind) in done: continue
            r = run(win, kind, rng); r.update(i=i, domain=dom); res.append(r); json.dump(res, open(out, 'w'))
            print(dom, i, kind, r['dim'], [round(L['A_E'], 1) for L in r['layers']][::3], [round(L['A_B'], 1) for L in r['layers']][::3], f'[{time.time()-t0:.0f}s]', flush=True)

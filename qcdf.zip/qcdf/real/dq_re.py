"""Independent re-evaluation of the surrogate-regret check of dq.py: the plan that looked best among the 30 best surrogate plans on the evaluation stream is re-evaluated, with the surrogate optimum, on a fresh stream."""
import sys, json, numpy as np
_ARGV = list(sys.argv); sys.argv = ['x']
import fullscale as FS
import dq as DQ
sys.argv = _ARGV
if __name__ == '__main__':
    old = {x['T0']: x for x in json.load(open('dq.json'))}; res = []
    for T0, x in old.items():
        P = FS.Problem(T0); h, J, *_ = DQ.build(P, 11, 12); P.h, P.J = h, J
        plans = DQ.topk_plans(P, h, J); sim = None
        a = x['a']; ib = a['argbest']
        for st in (199, 299):
            base = P.L(set(), FS.R_B, st).mean(); val = lambda S: float(100 * (base - P.L(set(S), FS.R_B, st).mean()) / base)
            res.append(dict(T0=T0, stream=st, opt=val(plans[0][1]), sel=val(plans[ib][1]), same_E=[round(e, 3) for e, _ in plans[:3]], old_opt=a['opt'], old_best=a['best_top']))
            print(res[-1], flush=True)
        json.dump(res, open('dq_re.json', 'w'))

"""Astronomical pilot: six-pixel Fermi-LAT instance solved with constraint-preserving QAOA at depths 1 to 4."""
import sys, numpy as np
sys.path.insert(0,'../out')
from qcdf_scaling import DickeSpace, qaoa_state, optimise_qaoa
PIX=[0,3,5,7,9,10]
v=np.array([0,.489,.310,1,.484,.826]);c=np.array([.639,.308,0,.878,.044,1])
r=np.array([.005,.249,0,1,.308,.892]);u=np.array([.548,1,.828,0,.133,.043])
h=1*c+.5*r+.3*u-2*v
EP=[(0,3),(0,5),(3,7),(5,9),(7,10),(9,10)]
ED=[(PIX.index(a),PIX.index(b)) for a,b in EP]
def solve(J,p=4,R=30,seed=0,pmax=None):
    sp=DickeSpace(6,3,ED);E=sp.energies(h,J)
    res=optimise_qaoa(sp,E,pmax or p,R,np.random.default_rng(seed))
    out={}
    for pp,rr in res.items():
        pr=np.abs(qaoa_state(rr.x,sp,E))**2; o=np.argmin(E)
        out[pp]=dict(Eopt=E.min(),Emean=rr.fun,Popt=pr[o],z=''.join(map(str,sp.Z[o])),x=rr.x,prob=pr,Z=sp.Z,E=E)
    return out
if __name__=="__main__":
    o=solve(0.3,pmax=4)
    for p,d in o.items(): print(p, d['z'], round(d['Eopt'],4), round(d['Emean'],4), round(d['Popt']*100,2))

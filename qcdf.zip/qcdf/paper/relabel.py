"""v14 terminology: expected-exposure ranking instead of value at risk, associated instead of identified (sky); v11 terminology (ASD-STE100 pass): the Dixie-only model is 'retrospective', the enumerated best plan of the
toy study is the 'enumerated optimum'. Applied after all generators, before build_v4.py."""
import re
fn = 'v4_body_filled.tex'; s = open(fn).read()
s = re.sub(r'(?m)^oracle & (active|late)', r'retrospective & \1', s)
TERMS = [('value-at-risk', 'expected-exposure'), ('Value-at-risk', 'Expected-exposure'), ('Value at risk', 'Expected exposure'),
         ('value at risk', 'expected exposure'), ('VaR', 'EE'),
         ('identified in DR', 'associated in DR'), ('identified sources', 'associated sources'), ('DR4 identifications', 'DR4 associations'),
         ('expected identifications', 'expected associations'), ('identifications', 'associations'), ('identification model', 'association model'),
         ('identified in DR4', 'associated in DR4'), ('unidentified', 'unassociated'), ('probability of identification', 'probability of association'),
         ('identified source', 'associated source'), ('identification probabilities', 'association probabilities'), ('identification randomness', 'association randomness'),
         ('covers 20 identified', 'covers 20 associated'), ('(expected identifications,', '(expected associations,')]
for a, b in TERMS: s = s.replace(a, b)
s = s.replace('The diagonal phase separator $e^{-i\\gamma \\Hloc} e^{-i\\gamma \\Hcorr}$ commutes', 'The diagonal phase separator $e^{-i\\gamma H_{\\rm diag}}$ commutes', 1)
s = s.replace('e^{-i\\gamma_\\ell (\\Hloc+\\Hcorr)}\\ket{D_k^N},', 'e^{-i\\gamma_\\ell H_{\\rm diag}}\\ket{D_k^N},', 1)
s = s.replace('largest expected exposure\n$H_iP_i$', 'largest expected exposure\n$H_iP_i$ (the expected-exposure ranking, EE)', 1)
open(fn, 'w').write(s)
import glob
for f in glob.glob('figures/tikz/*.tex'):
    t = open(f).read(); t0 = t
    for a, b in TERMS: t = t.replace(a, b)
    if t != t0: open(f, 'w').write(t)
R = {'figures/tikz/pipeline.tex': [('rolling $\\mid$ oracle', 'rolling $\\mid$ retrospective')],
     'figures/tikz/reliab.tex': [('oracle active,oracle late', 'retrospective active,retrospective late')],
     'figures/tikz/seq.tex': [('{oracle (enumeration)}', '{enumerated optimum}'), ('{oracle', '{enumerated optimum')],
     'figures/tikz/seqbig.tex': [('{oracle}', '{enumerated opt.}')]}
for f, reps in R.items():
    t = open(f).read()
    for a, b in reps: t = t.replace(a, b)
    open(f, 'w').write(t)
print('relabel ok', len(re.findall(r'\boracle\b', s)))

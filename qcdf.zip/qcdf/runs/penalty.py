"""Penalty-QUBO QAOA (X mixer, |+>^N start) vs constraint-preserving Dicke+XY, astro pilot."""
import numpy as np, json, itertools
from scipy.optimize import minimize
from pilot import h, ED
N,K,J=6,3,0.3
Z=np.array(list(itertools.product([0,1],repeat=N)))
s=1-2*Z
Ediag=Z@h+sum(J*s[:,i]*s[:,j] for i,j in ED)
w=Z.sum(1); feas=(w==K)
opt=np.argmin(np.where(feas,Ediag,np.inf))

def mix(psi,b):
    psi=psi.reshape([2]*N); c,sn=np.cos(b),-1j*np.sin(b)
    for q in range(N):
        psi=np.moveaxis(psi,q,0); a0,a1=psi[0].copy(),psi[1].copy()
        psi[0]=c*a0+sn*a1; psi[1]=sn*a0+c*a1; psi=np.moveaxis(psi,0,q)
    return psi.reshape(-1)

def state(x,Hc,p):
    psi=np.full(2**N,2**(-N/2),complex)
    for g,b in zip(x[:p],x[p:]):
        psi=psi*np.exp(-1j*g*Hc); psi=mix(psi,b)
    return psi
def run(lam,p=4,R=100,seed=0):
    Hc=Ediag+lam*(w-K)**2
    f=lambda x: float(np.real(np.vdot(state(x,Hc,p),Hc*state(x,Hc,p))))
    rng=np.random.default_rng(seed);best=None
    for _ in range(R):
        x0=np.concatenate([rng.uniform(0,2*np.pi,p),rng.uniform(0,np.pi,p)])
        r=minimize(f,x0,method='L-BFGS-B',bounds=[(0,2*np.pi)]*p+[(0,np.pi)]*p)
        if best is None or r.fun<best.fun: best=r
    pr=np.abs(state(best.x,Hc,p))**2
    pf=pr[feas].sum()
    return dict(lam=lam,p=p,Pfeas=float(pf),Popt=float(pr[opt]),Popt_feas=float(pr[opt]/pf),
                modal_feasible=bool(feas[np.argmax(pr)]),modal_is_opt=bool(np.argmax(pr)==opt),Emean=float(best.fun))
rows=[]
for p in [1,2,4]:
    for lam in [0.1,0.25,0.5,1,2,4,8,16]:
        r=run(lam,p=p); rows.append(r); print(r,flush=True)
json.dump(rows,open('penalty.json','w'))

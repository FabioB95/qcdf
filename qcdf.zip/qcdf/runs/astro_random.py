"""Sanity check (reviewer C6): the pilot uses the 6 HEALPix Nside=1 pixels closest to the Galactic plane. Repeat the identical pipeline (scalars of Eq. astro_mapping, J=0.3 on HEALPix adjacency, k=3, p=4, best of 30 restarts by energy) on 20 random 6-pixel subsets. Catalogue: 4FGL-DR4 from VizieR IX/72."""
import sys, json, itertools, numpy as np, pandas as pd, healpy as hp
from scipy.optimize import minimize
sys.path.insert(0, '../out')
from qcdf_scaling import DickeSpace, qaoa_state, qaoa_energy
d = pd.read_csv('../realdata/fermi/dr4.tsv', sep='\t', comment='#', skiprows=[1, 2])
d = d[pd.to_numeric(d.RAJ2000, errors='coerce').notna()]
for c in ['RAJ2000', 'DEJ2000', 'GLAT', 'Sig', 'EF100', 'VarInd']: d[c] = pd.to_numeric(d[c], errors='coerce')
d['pix'] = hp.ang2pix(1, d.RAJ2000.values, d.DEJ2000.values, lonlat=True)
d['_v'] = d.EF100 * (1 - d.Sig / d.Sig.max()); g = d.groupby('pix'); A = 41252.96 / 12
raw = dict(v=np.log(g._v.sum()), c=g.size() / g.EF100.mean(), r=0.6 / (g.GLAT.apply(lambda x: np.abs(x).mean()) + 1) + 0.4 * g.size() / A,
           u=g.VarInd.mean())
NB = {p: set(int(q) for q in hp.get_all_neighbours(1, p) if q >= 0) for p in range(12)}
mm = lambda x: (x - x.min()) / (x.max() - x.min())
def solve(PIX, rng):
    v, c, r, u = [mm(raw[k][PIX].values) for k in 'vcru']; h = c + 0.5 * r + 0.3 * u - 2 * v
    ed = [(a, b) for a, b in itertools.combinations(range(6), 2) if PIX[b] in NB[PIX[a]]]
    sp = DickeSpace(6, 3, ed); E = sp.energies(h, 0.3); o = int(np.argmin(E)); best = None
    for _ in range(30):
        x0 = np.concatenate([rng.uniform(0, 2 * np.pi, 4), rng.uniform(0, np.pi, 4)])
        rr = minimize(qaoa_energy, x0, args=(sp, E), method='L-BFGS-B', bounds=[(0, 2 * np.pi)] * 4 + [(0, np.pi)] * 4)
        best = rr if best is None or rr.fun < best.fun else best
    pr = np.abs(qaoa_state(best.x, sp, E)) ** 2
    gap = np.sort(E)[1] - E[0]
    return dict(pix=list(map(int, PIX)), n_edges=len(ed), Popt=float(pr[o]), modal_is_opt=bool(np.argmax(pr) == o), gap=float(gap))
rng = np.random.default_rng(42); res = [dict(kind='pilot', **solve([0, 3, 5, 7, 9, 10], rng))]
seen = set()
while len(res) < 21:
    P = tuple(sorted(rng.choice(12, 6, replace=False)))
    if P in seen or P == (0, 3, 5, 7, 9, 10): continue
    seen.add(P); res.append(dict(kind='random', **solve(list(P), rng))); print(res[-1], flush=True)
print(res[0])
R = [x for x in res if x['kind'] == 'random']
print('random: Popt mean', np.mean([x['Popt'] for x in R]), 'median', np.median([x['Popt'] for x in R]), 'min', min(x['Popt'] for x in R),
      'modal opt', sum(x['modal_is_opt'] for x in R), '/', len(R), 'edges', np.mean([x['n_edges'] for x in R]))
json.dump(res, open('astro_random.json', 'w'), indent=1)

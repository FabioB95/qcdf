"""Uncertainty-weighted XY mixer: beta_l * w_ij on edge (i,j), w_ij ∝ (u_i+u_j)/2 (mean 1). Controls: uniform (w=1) and shuffled-u (same weight distribution, random assignment)."""
import sys, numpy as np, json, math
sys.path.insert(0,'../out')
from scipy.optimize import minimize
from qcdf_scaling import DickeSpace, hex_patch, W_C,W_R,W_U,W_V
from pilot import h as h_astro, ED as ED_astro, u as u_astro
def state(x,sp,E,wts):
    p=len(x)//2; psi=np.full(sp.dim,1/math.sqrt(sp.dim),complex)
    for g,b in zip(x[:p],x[p:]):
        psi=psi*np.exp(-1j*g*E)
        for (a01,a10),wt in zip(sp.pairs,wts):
            cb,sb=math.cos(b*wt),math.sin(b*wt); x01,x10=psi[a01],psi[a10]
            psi[a01]=cb*x01-1j*sb*x10; psi[a10]=cb*x10-1j*sb*x01
    return psi
def solve(sp,E,wts,p,R,seed):
    f=lambda x: float(np.real(np.vdot(st:=state(x,sp,E,wts),E*st)))
    rng=np.random.default_rng(seed);best=None
    for _ in range(R):
        x0=np.concatenate([rng.uniform(0,2*np.pi,p),rng.uniform(0,np.pi,p)])
        r=minimize(f,x0,method='L-BFGS-B',bounds=[(0,2*np.pi)]*p+[(0,np.pi)]*p)
        if best is None or r.fun<best.fun: best=r
    pr=np.abs(state(best.x,sp,E,wts))**2; o=np.argmin(E)
    return float(best.fun), float(pr[o]), float((E.max()-best.fun)/(E.max()-E.min()))
def weights(u,ed,eps=0.1):
    w=np.array([(u[i]+u[j])/2+eps for i,j in ed]); return w/w.mean()
out=[]

sp=DickeSpace(6,3,ED_astro);E=sp.energies(h_astro,0.3)
rng=np.random.default_rng(7)
for p in [1,2,3,4]:
    for name,wts in [('uniform',np.ones(6)),('u-weighted',weights(u_astro,ED_astro))]+[(f'shuffled{t}',weights(rng.permutation(u_astro),ED_astro)) for t in range(5)]:
        Em,Po,r=solve(sp,E,wts,p,100,p)
        out.append(dict(inst='pilot',N=6,p=p,mixer=name,Emean=Em,Popt=Po,r=r)); print(out[-1],flush=True)

rng=np.random.default_rng(11)
for N in [8,10,12]:
    ed=hex_patch(N); sp=DickeSpace(N,N//2,ed)
    for inst in range(8):
        v,c,r_,u=rng.random((4,N)); hh=W_C*c+W_R*r_+W_U*u-W_V*v; E=sp.energies(hh,0.3)
        for p in [2,4]:
            for name,wts in [('uniform',np.ones(len(ed))),('u-weighted',weights(u,ed)),('shuffled',weights(rng.permutation(u),ed))]:
                Em,Po,rr=solve(sp,E,wts,p,20,inst)
                out.append(dict(inst=inst,N=N,p=p,mixer=name,Emean=Em,Popt=Po,r=rr)); print(out[-1],flush=True)
json.dump(out,open('wmixer.json','w'))

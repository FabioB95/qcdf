"""Fixed-angle time-to-solution (TTS) scaling study, LABS-style methodology. 1. Train one set of QAOA angles per depth p on 20 instances at N=8 (maximise mean approximation ratio) -> parameter transfer, no per-instance optimisation. 2. Apply the same angles to fresh instances N=6..20 (20 per N). 3. TTS_QAOA = ln(0.01)/ln(1-P_opt) shots (99% success); with quantum minimum finding / amplitude amplification the cost scales as ~1/sqrt(P_opt). 4. SA baseline: fixed budget of S sweeps per run; success prob p_s over 200 runs; TTS_SA = S*N * ln(0.01)/ln(1-p_s) single-spin-swap updates. 5. Fit log2 TTS = a + kappa*N for each solver."""
import numpy as np, math, json, sys, time
from scipy.optimize import minimize
from itertools import combinations
sys.path.insert(0, '../out'); sys.path.insert(0, '.')
from qcdf_scaling import hex_patch, W_C, W_R, W_U, W_V
J = 0.3

class Space:
    def __init__(s, n, k, edges):
        s.n, s.k, s.edges = n, k, edges
        masks = np.array([sum(1 << i for i in c) for c in combinations(range(n), k)], dtype=np.int64)
        order = np.argsort(masks); s.masks = masks[order]
        s.Z = ((s.masks[:, None] >> np.arange(n)) & 1).astype(np.int8)
        s.dim = len(s.masks); s.pairs = []
        for i, j in edges:
            a01 = np.where((s.Z[:, i] == 0) & (s.Z[:, j] == 1))[0]
            tgt = s.masks[a01] ^ ((1 << i) | (1 << j))
            s.pairs.append((a01, np.searchsorted(s.masks, tgt)))
    def energies(s, h):
        sp = 1 - 2 * s.Z.astype(float); e = s.Z @ h
        for i, j in s.edges: e = e + J * sp[:, i] * sp[:, j]
        return e

def evolve(x, sp, E):
    p = len(x) // 2; psi = np.full(sp.dim, 1 / math.sqrt(sp.dim), complex)
    for g, b in zip(x[:p], x[p:]):
        psi *= np.exp(-1j * g * E); cb, sb = math.cos(b), math.sin(b)
        for a01, a10 in sp.pairs:
            x01, x10 = psi[a01], psi[a10]
            psi[a01] = cb * x01 - 1j * sb * x10; psi[a10] = cb * x10 - 1j * sb * x01
    return psi

def instance(n, rng):
    v, c, r, u = rng.random((4, n)); return W_C * c + W_R * r + W_U * u - W_V * v

def sa_success(h, edges, k, sweeps, runs, rng, Estar):
    n = len(h); nb = [[] for _ in range(n)]
    for i, j in edges: nb[i].append(j); nb[j].append(i)
    succ = 0; steps = sweeps * n
    for _ in range(runs):
        z = np.zeros(n, int); z[rng.choice(n, k, replace=False)] = 1; s = 1 - 2 * z
        e = z @ h + J * sum(s[i] * s[j] for i, j in edges); best = e
        for t in range(steps):
            T = 2.0 * (0.01 / 2.0) ** (t / max(steps - 1, 1))
            on = np.flatnonzero(z); off = np.flatnonzero(1 - z)
            i = on[rng.integers(len(on))]; j = off[rng.integers(len(off))]

            z2 = z.copy(); z2[i], z2[j] = 0, 1; s2 = 1 - 2 * z2
            loc = set(nb[i]) | set(nb[j]) | {i, j}
            de = (h[j] - h[i]) + J * sum((s2[a] * s2[b] - s[a] * s[b]) for a, b in edges if a in loc or b in loc)
            if de <= 0 or rng.random() < math.exp(-de / T):
                z, s, e = z2, s2, e + de; best = min(best, e)
        succ += best <= Estar + 1e-9
    return succ / runs

def tts(p_s):
    if p_s <= 0: return np.inf
    if p_s >= 1: return 1.0
    return math.log(0.01) / math.log(1 - p_s)

if __name__ == '__main__':
    rng = np.random.default_rng(2026)

    ntr = 8; edtr = hex_patch(ntr); sptr = Space(ntr, ntr // 2, edtr)
    train = []
    for _ in range(20):
        E = sptr.energies(instance(ntr, rng)); train.append((E, E.min(), E.max()))
    def loss(x):
        return -np.mean([(Emax - np.real(np.vdot(ps := evolve(x, sptr, E), E * ps))) / (Emax - Emin)
                         for E, Emin, Emax in train])
    angles = {}; prev = None
    for p in range(1, 7):
        starts = []
        if prev is not None:
            q = p - 1
            def interp(x):
                xo = np.concatenate([[0.0], x, [0.0]])
                return np.array([((i - 1) / q) * xo[i - 1] + ((q - i + 1) / q) * xo[i] for i in range(1, p + 1)])
            starts.append(np.concatenate([interp(prev[:q]), interp(prev[q:])]))
        for _ in range(8):
            starts.append(np.concatenate([rng.uniform(0, 2 * np.pi, p), rng.uniform(0, np.pi, p)]))
        best = min((minimize(loss, x0, method='L-BFGS-B',
                             bounds=[(0, 2 * np.pi)] * p + [(0, np.pi)] * p) for x0 in starts), key=lambda r: r.fun)
        angles[p] = best.x.tolist(); prev = best.x
        print(f"train p={p}: mean r={-best.fun:.4f}", flush=True)

    rows = []
    for n in range(6, 21, 2):
        k = n // 2; ed = hex_patch(n); t0 = time.time(); sp = Space(n, k, ed)
        for inst in range(20):
            h = instance(n, rng); E = sp.energies(h); Estar = E.min(); opt = np.isclose(E, Estar)
            row = dict(N=n, inst=inst, dim=sp.dim, P_unif=float(opt.sum() / sp.dim))
            for p, x in angles.items():
                pr = np.abs(evolve(np.array(x), sp, E)) ** 2
                row[f'P_p{p}'] = float(pr[opt].sum())
                row[f'r_p{p}'] = float((E.max() - pr @ E) / (E.max() - Estar))
            for S in (1, 5):
                row[f'psa_{S}'] = sa_success(h, ed, k, S, 100, rng, Estar)
            rows.append(row)
        print(f"N={n} done ({time.time() - t0:.0f}s)  P_p6 mean={np.mean([r['P_p6'] for r in rows if r['N']==n]):.4g}"
              f" unif={rows[-1]['P_unif']:.3g}  psa1={np.mean([r['psa_1'] for r in rows if r['N']==n]):.3f}"
              f" psa5={np.mean([r['psa_5'] for r in rows if r['N']==n]):.3f}", flush=True)
        json.dump(dict(angles=angles, rows=rows), open('tts.json', 'w'))

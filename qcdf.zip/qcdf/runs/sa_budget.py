"""Reviewer C4: is the SA scaling exponent an artefact of the sweep budget? Fresh instances N=6..20 (20 per N), SA with S in {1,2,5,20,100} sweeps; TTS_SA(S) = S*N*ln(0.01)/ln(1-p_s) single swap updates; exponent kappa from log2 median TTS vs N, per fixed S and for the per-N optimal S."""
import sys, json, math, numpy as np
sys.path.insert(0, '.'); sys.path.insert(0, '../out')
from tts import Space, instance, sa_success, tts
from qcdf_scaling import hex_patch
rng = np.random.default_rng(31); rows = []
for n in range(6, 21, 2):
    k = n // 2; ed = hex_patch(n); sp = Space(n, k, ed)
    for inst in range(20):
        h = instance(n, rng); Estar = sp.energies(h).min(); row = dict(N=n, inst=inst)
        for S in (1, 2, 5, 20, 100):
            row[f'psa_{S}'] = sa_success(h, ed, k, S, 100 if S < 100 else 40, rng, Estar)
        rows.append(row)
    print(n, {S: round(np.mean([r[f'psa_{S}'] for r in rows if r['N'] == n]), 3) for S in (1, 2, 5, 20, 100)}, flush=True)
    json.dump(rows, open('sa_budget.json', 'w'))
Ns = sorted(set(r['N'] for r in rows)); out = {}
for S in (1, 2, 5, 20, 100):
    med = [np.median([S * n * tts(r[f'psa_{S}']) for r in rows if r['N'] == n]) for n in Ns]
    out[S] = (np.polyfit(Ns, np.log2(med), 1)[0], med)
best = [min(np.median([S * n * tts(r[f'psa_{S}']) for r in rows if r['N'] == n]) for S in (1, 2, 5, 20, 100)) for n in Ns]
print({S: round(v[0], 3) for S, v in out.items()}, 'optimal-S kappa', round(np.polyfit(Ns, np.log2(best), 1)[0], 3))
json.dump(dict(rows=rows, kappa={str(S): v[0] for S, v in out.items()}, kappa_opt=np.polyfit(Ns, np.log2(best), 1)[0],
               med={str(S): v[1] for S, v in out.items()}, best=best, Ns=Ns), open('sa_budget.json', 'w'))
